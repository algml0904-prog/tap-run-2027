'use strict';
const http = require('node:http');
const crypto = require('node:crypto');
// QR code library by Kazuhiko Arase (MIT), source copyright preserved below.
const __QR_MODULES = Object.create(null);
const __QR_CACHE = Object.create(null);
function __qrRequire(id) {
 if (__QR_CACHE[id]) return __QR_CACHE[id].exports;
 if (!__QR_MODULES[id]) throw new Error('Missing QR module: '+id);
 const module={exports:{}}; __QR_CACHE[id]=module;
 __QR_MODULES[id](module,module.exports,p=>__qrRequire(p.replace(/^\.\//,'').replace(/\.js$/,'')));
 return module.exports;
}
__QR_MODULES["QR8bitByte"]=function(module,exports,require){
var QRMode = require('./QRMode');

function QR8bitByte(data) {
	this.mode = QRMode.MODE_8BIT_BYTE;
	this.data = data;
}

QR8bitByte.prototype = {

	getLength : function() {
		return this.data.length;
	},
	
	write : function(buffer) {
		for (var i = 0; i < this.data.length; i++) {
			// not JIS ...
			buffer.put(this.data.charCodeAt(i), 8);
		}
	}
};

module.exports = QR8bitByte;

};
__QR_MODULES["QRBitBuffer"]=function(module,exports,require){
function QRBitBuffer() {
	this.buffer = [];
	this.length = 0;
}

QRBitBuffer.prototype = {

	get : function(index) {
		var bufIndex = Math.floor(index / 8);
		return ( (this.buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
	},
	
	put : function(num, length) {
		for (var i = 0; i < length; i++) {
			this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
		}
	},
	
	getLengthInBits : function() {
		return this.length;
	},
	
	putBit : function(bit) {
	
		var bufIndex = Math.floor(this.length / 8);
		if (this.buffer.length <= bufIndex) {
			this.buffer.push(0);
		}
	
		if (bit) {
			this.buffer[bufIndex] |= (0x80 >>> (this.length % 8) );
		}
	
		this.length++;
	}
};

module.exports = QRBitBuffer;

};
__QR_MODULES["QRErrorCorrectLevel"]=function(module,exports,require){
module.exports = {
	L : 1,
	M : 0,
	Q : 3,
	H : 2
};


};
__QR_MODULES["QRMaskPattern"]=function(module,exports,require){
module.exports = {
	PATTERN000 : 0,
	PATTERN001 : 1,
	PATTERN010 : 2,
	PATTERN011 : 3,
	PATTERN100 : 4,
	PATTERN101 : 5,
	PATTERN110 : 6,
	PATTERN111 : 7
};

};
__QR_MODULES["QRMath"]=function(module,exports,require){
var QRMath = {

	glog : function(n) {
	
		if (n < 1) {
			throw new Error("glog(" + n + ")");
		}
		
		return QRMath.LOG_TABLE[n];
	},
	
	gexp : function(n) {
	
		while (n < 0) {
			n += 255;
		}
	
		while (n >= 256) {
			n -= 255;
		}
	
		return QRMath.EXP_TABLE[n];
	},
	
	EXP_TABLE : new Array(256),
	
	LOG_TABLE : new Array(256)

};
	
for (var i = 0; i < 8; i++) {
	QRMath.EXP_TABLE[i] = 1 << i;
}
for (var i = 8; i < 256; i++) {
	QRMath.EXP_TABLE[i] = QRMath.EXP_TABLE[i - 4]
		^ QRMath.EXP_TABLE[i - 5]
		^ QRMath.EXP_TABLE[i - 6]
		^ QRMath.EXP_TABLE[i - 8];
}
for (var i = 0; i < 255; i++) {
	QRMath.LOG_TABLE[QRMath.EXP_TABLE[i] ] = i;
}

module.exports = QRMath;

};
__QR_MODULES["QRMode"]=function(module,exports,require){
module.exports = {
    MODE_NUMBER :       1 << 0,
    MODE_ALPHA_NUM :    1 << 1,
    MODE_8BIT_BYTE :    1 << 2,
    MODE_KANJI :        1 << 3
};

};
__QR_MODULES["QRPolynomial"]=function(module,exports,require){
var QRMath = require('./QRMath');

function QRPolynomial(num, shift) {
	if (num.length === undefined) {
		throw new Error(num.length + "/" + shift);
	}

	var offset = 0;

	while (offset < num.length && num[offset] === 0) {
		offset++;
	}

	this.num = new Array(num.length - offset + shift);
	for (var i = 0; i < num.length - offset; i++) {
		this.num[i] = num[i + offset];
	}
}

QRPolynomial.prototype = {

	get : function(index) {
		return this.num[index];
	},
	
	getLength : function() {
		return this.num.length;
	},
	
	multiply : function(e) {
	
		var num = new Array(this.getLength() + e.getLength() - 1);
	
		for (var i = 0; i < this.getLength(); i++) {
			for (var j = 0; j < e.getLength(); j++) {
				num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i) ) + QRMath.glog(e.get(j) ) );
			}
		}
	
		return new QRPolynomial(num, 0);
	},
	
	mod : function(e) {
	
		if (this.getLength() - e.getLength() < 0) {
			return this;
		}
	
		var ratio = QRMath.glog(this.get(0) ) - QRMath.glog(e.get(0) );
	
		var num = new Array(this.getLength() );
		
		for (var i = 0; i < this.getLength(); i++) {
			num[i] = this.get(i);
		}
		
		for (var x = 0; x < e.getLength(); x++) {
			num[x] ^= QRMath.gexp(QRMath.glog(e.get(x) ) + ratio);
		}
	
		// recursive call
		return new QRPolynomial(num, 0).mod(e);
	}
};

module.exports = QRPolynomial;

};
__QR_MODULES["QRRSBlock"]=function(module,exports,require){
var QRErrorCorrectLevel = require('./QRErrorCorrectLevel');

function QRRSBlock(totalCount, dataCount) {
	this.totalCount = totalCount;
	this.dataCount  = dataCount;
}

QRRSBlock.RS_BLOCK_TABLE = [

	// L
	// M
	// Q
	// H

	// 1
	[1, 26, 19],
	[1, 26, 16],
	[1, 26, 13],
	[1, 26, 9],
	
	// 2
	[1, 44, 34],
	[1, 44, 28],
	[1, 44, 22],
	[1, 44, 16],

	// 3
	[1, 70, 55],
	[1, 70, 44],
	[2, 35, 17],
	[2, 35, 13],

	// 4		
	[1, 100, 80],
	[2, 50, 32],
	[2, 50, 24],
	[4, 25, 9],
	
	// 5
	[1, 134, 108],
	[2, 67, 43],
	[2, 33, 15, 2, 34, 16],
	[2, 33, 11, 2, 34, 12],
	
	// 6
	[2, 86, 68],
	[4, 43, 27],
	[4, 43, 19],
	[4, 43, 15],
	
	// 7		
	[2, 98, 78],
	[4, 49, 31],
	[2, 32, 14, 4, 33, 15],
	[4, 39, 13, 1, 40, 14],
	
	// 8
	[2, 121, 97],
	[2, 60, 38, 2, 61, 39],
	[4, 40, 18, 2, 41, 19],
	[4, 40, 14, 2, 41, 15],
	
	// 9
	[2, 146, 116],
	[3, 58, 36, 2, 59, 37],
	[4, 36, 16, 4, 37, 17],
	[4, 36, 12, 4, 37, 13],
	
	// 10		
	[2, 86, 68, 2, 87, 69],
	[4, 69, 43, 1, 70, 44],
	[6, 43, 19, 2, 44, 20],
	[6, 43, 15, 2, 44, 16],

	// 11
	[4, 101, 81],
	[1, 80, 50, 4, 81, 51],
	[4, 50, 22, 4, 51, 23],
	[3, 36, 12, 8, 37, 13],

	// 12
	[2, 116, 92, 2, 117, 93],
	[6, 58, 36, 2, 59, 37],
	[4, 46, 20, 6, 47, 21],
	[7, 42, 14, 4, 43, 15],

	// 13
	[4, 133, 107],
	[8, 59, 37, 1, 60, 38],
	[8, 44, 20, 4, 45, 21],
	[12, 33, 11, 4, 34, 12],

	// 14
	[3, 145, 115, 1, 146, 116],
	[4, 64, 40, 5, 65, 41],
	[11, 36, 16, 5, 37, 17],
	[11, 36, 12, 5, 37, 13],

	// 15
	[5, 109, 87, 1, 110, 88],
	[5, 65, 41, 5, 66, 42],
	[5, 54, 24, 7, 55, 25],
	[11, 36, 12],

	// 16
	[5, 122, 98, 1, 123, 99],
	[7, 73, 45, 3, 74, 46],
	[15, 43, 19, 2, 44, 20],
	[3, 45, 15, 13, 46, 16],

	// 17
	[1, 135, 107, 5, 136, 108],
	[10, 74, 46, 1, 75, 47],
	[1, 50, 22, 15, 51, 23],
	[2, 42, 14, 17, 43, 15],

	// 18
	[5, 150, 120, 1, 151, 121],
	[9, 69, 43, 4, 70, 44],
	[17, 50, 22, 1, 51, 23],
	[2, 42, 14, 19, 43, 15],

	// 19
	[3, 141, 113, 4, 142, 114],
	[3, 70, 44, 11, 71, 45],
	[17, 47, 21, 4, 48, 22],
	[9, 39, 13, 16, 40, 14],

	// 20
	[3, 135, 107, 5, 136, 108],
	[3, 67, 41, 13, 68, 42],
	[15, 54, 24, 5, 55, 25],
	[15, 43, 15, 10, 44, 16],

	// 21
	[4, 144, 116, 4, 145, 117],
	[17, 68, 42],
	[17, 50, 22, 6, 51, 23],
	[19, 46, 16, 6, 47, 17],

	// 22
	[2, 139, 111, 7, 140, 112],
	[17, 74, 46],
	[7, 54, 24, 16, 55, 25],
	[34, 37, 13],

	// 23
	[4, 151, 121, 5, 152, 122],
	[4, 75, 47, 14, 76, 48],
	[11, 54, 24, 14, 55, 25],
	[16, 45, 15, 14, 46, 16],

	// 24
	[6, 147, 117, 4, 148, 118],
	[6, 73, 45, 14, 74, 46],
	[11, 54, 24, 16, 55, 25],
	[30, 46, 16, 2, 47, 17],

	// 25
	[8, 132, 106, 4, 133, 107],
	[8, 75, 47, 13, 76, 48],
	[7, 54, 24, 22, 55, 25],
	[22, 45, 15, 13, 46, 16],

	// 26
	[10, 142, 114, 2, 143, 115],
	[19, 74, 46, 4, 75, 47],
	[28, 50, 22, 6, 51, 23],
	[33, 46, 16, 4, 47, 17],

	// 27
	[8, 152, 122, 4, 153, 123],
	[22, 73, 45, 3, 74, 46],
	[8, 53, 23, 26, 54, 24],
	[12, 45, 15, 28, 46, 16],

	// 28
	[3, 147, 117, 10, 148, 118],
	[3, 73, 45, 23, 74, 46],
	[4, 54, 24, 31, 55, 25],
	[11, 45, 15, 31, 46, 16],

	// 29
	[7, 146, 116, 7, 147, 117],
	[21, 73, 45, 7, 74, 46],
	[1, 53, 23, 37, 54, 24],
	[19, 45, 15, 26, 46, 16],

	// 30
	[5, 145, 115, 10, 146, 116],
	[19, 75, 47, 10, 76, 48],
	[15, 54, 24, 25, 55, 25],
	[23, 45, 15, 25, 46, 16],

	// 31
	[13, 145, 115, 3, 146, 116],
	[2, 74, 46, 29, 75, 47],
	[42, 54, 24, 1, 55, 25],
	[23, 45, 15, 28, 46, 16],

	// 32
	[17, 145, 115],
	[10, 74, 46, 23, 75, 47],
	[10, 54, 24, 35, 55, 25],
	[19, 45, 15, 35, 46, 16],

	// 33
	[17, 145, 115, 1, 146, 116],
	[14, 74, 46, 21, 75, 47],
	[29, 54, 24, 19, 55, 25],
	[11, 45, 15, 46, 46, 16],

	// 34
	[13, 145, 115, 6, 146, 116],
	[14, 74, 46, 23, 75, 47],
	[44, 54, 24, 7, 55, 25],
	[59, 46, 16, 1, 47, 17],

	// 35
	[12, 151, 121, 7, 152, 122],
	[12, 75, 47, 26, 76, 48],
	[39, 54, 24, 14, 55, 25],
	[22, 45, 15, 41, 46, 16],

	// 36
	[6, 151, 121, 14, 152, 122],
	[6, 75, 47, 34, 76, 48],
	[46, 54, 24, 10, 55, 25],
	[2, 45, 15, 64, 46, 16],

	// 37
	[17, 152, 122, 4, 153, 123],
	[29, 74, 46, 14, 75, 47],
	[49, 54, 24, 10, 55, 25],
	[24, 45, 15, 46, 46, 16],

	// 38
	[4, 152, 122, 18, 153, 123],
	[13, 74, 46, 32, 75, 47],
	[48, 54, 24, 14, 55, 25],
	[42, 45, 15, 32, 46, 16],

	// 39
	[20, 147, 117, 4, 148, 118],
	[40, 75, 47, 7, 76, 48],
	[43, 54, 24, 22, 55, 25],
	[10, 45, 15, 67, 46, 16],

	// 40
	[19, 148, 118, 6, 149, 119],
	[18, 75, 47, 31, 76, 48],
	[34, 54, 24, 34, 55, 25],
	[20, 45, 15, 61, 46, 16]
];

QRRSBlock.getRSBlocks = function(typeNumber, errorCorrectLevel) {
	
	var rsBlock = QRRSBlock.getRsBlockTable(typeNumber, errorCorrectLevel);
	
	if (rsBlock === undefined) {
		throw new Error("bad rs block @ typeNumber:" + typeNumber + "/errorCorrectLevel:" + errorCorrectLevel);
	}

	var length = rsBlock.length / 3;
	
	var list = [];
	
	for (var i = 0; i < length; i++) {

		var count = rsBlock[i * 3 + 0];
		var totalCount = rsBlock[i * 3 + 1];
		var dataCount  = rsBlock[i * 3 + 2];

		for (var j = 0; j < count; j++) {
			list.push(new QRRSBlock(totalCount, dataCount) );	
		}
	}
	
	return list;
};

QRRSBlock.getRsBlockTable = function(typeNumber, errorCorrectLevel) {

	switch(errorCorrectLevel) {
	case QRErrorCorrectLevel.L :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
	case QRErrorCorrectLevel.M :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
	case QRErrorCorrectLevel.Q :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
	case QRErrorCorrectLevel.H :
		return QRRSBlock.RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
	default :
		return undefined;
	}
};

module.exports = QRRSBlock;

};
__QR_MODULES["QRUtil"]=function(module,exports,require){
var QRMode = require('./QRMode');
var QRPolynomial = require('./QRPolynomial');
var QRMath = require('./QRMath');
var QRMaskPattern = require('./QRMaskPattern');

var QRUtil = {

    PATTERN_POSITION_TABLE : [
        [],
        [6, 18],
        [6, 22],
        [6, 26],
        [6, 30],
        [6, 34],
        [6, 22, 38],
        [6, 24, 42],
        [6, 26, 46],
        [6, 28, 50],
        [6, 30, 54],        
        [6, 32, 58],
        [6, 34, 62],
        [6, 26, 46, 66],
        [6, 26, 48, 70],
        [6, 26, 50, 74],
        [6, 30, 54, 78],
        [6, 30, 56, 82],
        [6, 30, 58, 86],
        [6, 34, 62, 90],
        [6, 28, 50, 72, 94],
        [6, 26, 50, 74, 98],
        [6, 30, 54, 78, 102],
        [6, 28, 54, 80, 106],
        [6, 32, 58, 84, 110],
        [6, 30, 58, 86, 114],
        [6, 34, 62, 90, 118],
        [6, 26, 50, 74, 98, 122],
        [6, 30, 54, 78, 102, 126],
        [6, 26, 52, 78, 104, 130],
        [6, 30, 56, 82, 108, 134],
        [6, 34, 60, 86, 112, 138],
        [6, 30, 58, 86, 114, 142],
        [6, 34, 62, 90, 118, 146],
        [6, 30, 54, 78, 102, 126, 150],
        [6, 24, 50, 76, 102, 128, 154],
        [6, 28, 54, 80, 106, 132, 158],
        [6, 32, 58, 84, 110, 136, 162],
        [6, 26, 54, 82, 110, 138, 166],
        [6, 30, 58, 86, 114, 142, 170]
    ],

    G15 : (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0),
    G18 : (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0),
    G15_MASK : (1 << 14) | (1 << 12) | (1 << 10)    | (1 << 4) | (1 << 1),

    getBCHTypeInfo : function(data) {
        var d = data << 10;
        while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15) >= 0) {
            d ^= (QRUtil.G15 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15) ) );    
        }
        return ( (data << 10) | d) ^ QRUtil.G15_MASK;
    },

    getBCHTypeNumber : function(data) {
        var d = data << 12;
        while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18) >= 0) {
            d ^= (QRUtil.G18 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18) ) );    
        }
        return (data << 12) | d;
    },

    getBCHDigit : function(data) {

        var digit = 0;

        while (data !== 0) {
            digit++;
            data >>>= 1;
        }

        return digit;
    },

    getPatternPosition : function(typeNumber) {
        return QRUtil.PATTERN_POSITION_TABLE[typeNumber - 1];
    },

    getMask : function(maskPattern, i, j) {
        
        switch (maskPattern) {
            
        case QRMaskPattern.PATTERN000 : return (i + j) % 2 === 0;
        case QRMaskPattern.PATTERN001 : return i % 2 === 0;
        case QRMaskPattern.PATTERN010 : return j % 3 === 0;
        case QRMaskPattern.PATTERN011 : return (i + j) % 3 === 0;
        case QRMaskPattern.PATTERN100 : return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 === 0;
        case QRMaskPattern.PATTERN101 : return (i * j) % 2 + (i * j) % 3 === 0;
        case QRMaskPattern.PATTERN110 : return ( (i * j) % 2 + (i * j) % 3) % 2 === 0;
        case QRMaskPattern.PATTERN111 : return ( (i * j) % 3 + (i + j) % 2) % 2 === 0;

        default :
            throw new Error("bad maskPattern:" + maskPattern);
        }
    },

    getErrorCorrectPolynomial : function(errorCorrectLength) {

        var a = new QRPolynomial([1], 0);

        for (var i = 0; i < errorCorrectLength; i++) {
            a = a.multiply(new QRPolynomial([1, QRMath.gexp(i)], 0) );
        }

        return a;
    },

    getLengthInBits : function(mode, type) {

        if (1 <= type && type < 10) {

            // 1 - 9

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 10;
            case QRMode.MODE_ALPHA_NUM  : return 9;
            case QRMode.MODE_8BIT_BYTE  : return 8;
            case QRMode.MODE_KANJI      : return 8;
            default :
                throw new Error("mode:" + mode);
            }

        } else if (type < 27) {

            // 10 - 26

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 12;
            case QRMode.MODE_ALPHA_NUM  : return 11;
            case QRMode.MODE_8BIT_BYTE  : return 16;
            case QRMode.MODE_KANJI      : return 10;
            default :
                throw new Error("mode:" + mode);
            }

        } else if (type < 41) {

            // 27 - 40

            switch(mode) {
            case QRMode.MODE_NUMBER     : return 14;
            case QRMode.MODE_ALPHA_NUM  : return 13;
            case QRMode.MODE_8BIT_BYTE  : return 16;
            case QRMode.MODE_KANJI      : return 12;
            default :
                throw new Error("mode:" + mode);
            }

        } else {
            throw new Error("type:" + type);
        }
    },

    getLostPoint : function(qrCode) {
        
        var moduleCount = qrCode.getModuleCount();
        var lostPoint = 0;
        var row = 0; 
        var col = 0;

        
        // LEVEL1
        
        for (row = 0; row < moduleCount; row++) {

            for (col = 0; col < moduleCount; col++) {

                var sameCount = 0;
                var dark = qrCode.isDark(row, col);

                for (var r = -1; r <= 1; r++) {

                    if (row + r < 0 || moduleCount <= row + r) {
                        continue;
                    }

                    for (var c = -1; c <= 1; c++) {

                        if (col + c < 0 || moduleCount <= col + c) {
                            continue;
                        }

                        if (r === 0 && c === 0) {
                            continue;
                        }

                        if (dark === qrCode.isDark(row + r, col + c) ) {
                            sameCount++;
                        }
                    }
                }

                if (sameCount > 5) {
                    lostPoint += (3 + sameCount - 5);
                }
            }
        }

        // LEVEL2

        for (row = 0; row < moduleCount - 1; row++) {
            for (col = 0; col < moduleCount - 1; col++) {
                var count = 0;
                if (qrCode.isDark(row,     col    ) ) count++;
                if (qrCode.isDark(row + 1, col    ) ) count++;
                if (qrCode.isDark(row,     col + 1) ) count++;
                if (qrCode.isDark(row + 1, col + 1) ) count++;
                if (count === 0 || count === 4) {
                    lostPoint += 3;
                }
            }
        }

        // LEVEL3

        for (row = 0; row < moduleCount; row++) {
            for (col = 0; col < moduleCount - 6; col++) {
                if (qrCode.isDark(row, col) && 
                        !qrCode.isDark(row, col + 1) && 
                         qrCode.isDark(row, col + 2) && 
                         qrCode.isDark(row, col + 3) && 
                         qrCode.isDark(row, col + 4) && 
                        !qrCode.isDark(row, col + 5) && 
                         qrCode.isDark(row, col + 6) ) {
                    lostPoint += 40;
                }
            }
        }

        for (col = 0; col < moduleCount; col++) {
            for (row = 0; row < moduleCount - 6; row++) {
                if (qrCode.isDark(row, col) &&
                        !qrCode.isDark(row + 1, col) &&
                         qrCode.isDark(row + 2, col) &&
                         qrCode.isDark(row + 3, col) &&
                         qrCode.isDark(row + 4, col) &&
                        !qrCode.isDark(row + 5, col) &&
                         qrCode.isDark(row + 6, col) ) {
                    lostPoint += 40;
                }
            }
        }

        // LEVEL4
        
        var darkCount = 0;

        for (col = 0; col < moduleCount; col++) {
            for (row = 0; row < moduleCount; row++) {
                if (qrCode.isDark(row, col) ) {
                    darkCount++;
                }
            }
        }
        
        var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
        lostPoint += ratio * 10;

        return lostPoint;       
    }

};

module.exports = QRUtil;

};
__QR_MODULES["index"]=function(module,exports,require){
//---------------------------------------------------------------------
// QRCode for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//   http://www.opensource.org/licenses/mit-license.php
//
// The word "QR Code" is registered trademark of 
// DENSO WAVE INCORPORATED
//   http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------
// Modified to work in node for this project (and some refactoring)
//---------------------------------------------------------------------

var QR8bitByte = require('./QR8bitByte');
var QRUtil = require('./QRUtil');
var QRPolynomial = require('./QRPolynomial');
var QRRSBlock = require('./QRRSBlock');
var QRBitBuffer = require('./QRBitBuffer');

function QRCode(typeNumber, errorCorrectLevel) {
	this.typeNumber = typeNumber;
	this.errorCorrectLevel = errorCorrectLevel;
	this.modules = null;
	this.moduleCount = 0;
	this.dataCache = null;
	this.dataList = [];
}

QRCode.prototype = {
	
	addData : function(data) {
		var newData = new QR8bitByte(data);
		this.dataList.push(newData);
		this.dataCache = null;
	},
	
	isDark : function(row, col) {
		if (row < 0 || this.moduleCount <= row || col < 0 || this.moduleCount <= col) {
			throw new Error(row + "," + col);
		}
		return this.modules[row][col];
	},

	getModuleCount : function() {
		return this.moduleCount;
	},
	
	make : function() {
		// Calculate automatically typeNumber if provided is < 1
		if (this.typeNumber < 1 ){
			var typeNumber = 1;
			for (typeNumber = 1; typeNumber < 40; typeNumber++) {
				var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, this.errorCorrectLevel);

				var buffer = new QRBitBuffer();
				var totalDataCount = 0;
				for (var i = 0; i < rsBlocks.length; i++) {
					totalDataCount += rsBlocks[i].dataCount;
				}

				for (var x = 0; x < this.dataList.length; x++) {
					var data = this.dataList[x];
					buffer.put(data.mode, 4);
					buffer.put(data.getLength(), QRUtil.getLengthInBits(data.mode, typeNumber) );
					data.write(buffer);
				}
				if (buffer.getLengthInBits() <= totalDataCount * 8)
					break;
			}
			this.typeNumber = typeNumber;
		}
		this.makeImpl(false, this.getBestMaskPattern() );
	},
	
	makeImpl : function(test, maskPattern) {
		
		this.moduleCount = this.typeNumber * 4 + 17;
		this.modules = new Array(this.moduleCount);
		
		for (var row = 0; row < this.moduleCount; row++) {
			
			this.modules[row] = new Array(this.moduleCount);
			
			for (var col = 0; col < this.moduleCount; col++) {
				this.modules[row][col] = null;//(col + row) % 3;
			}
		}
	
		this.setupPositionProbePattern(0, 0);
		this.setupPositionProbePattern(this.moduleCount - 7, 0);
		this.setupPositionProbePattern(0, this.moduleCount - 7);
		this.setupPositionAdjustPattern();
		this.setupTimingPattern();
		this.setupTypeInfo(test, maskPattern);
		
		if (this.typeNumber >= 7) {
			this.setupTypeNumber(test);
		}
	
		if (this.dataCache === null) {
			this.dataCache = QRCode.createData(this.typeNumber, this.errorCorrectLevel, this.dataList);
		}
	
		this.mapData(this.dataCache, maskPattern);
	},

	setupPositionProbePattern : function(row, col)  {
		
		for (var r = -1; r <= 7; r++) {
			
			if (row + r <= -1 || this.moduleCount <= row + r) continue;
			
			for (var c = -1; c <= 7; c++) {
				
				if (col + c <= -1 || this.moduleCount <= col + c) continue;
				
				if ( (0 <= r && r <= 6 && (c === 0 || c === 6) ) || 
                     (0 <= c && c <= 6 && (r === 0 || r === 6) ) || 
                     (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
					this.modules[row + r][col + c] = true;
				} else {
					this.modules[row + r][col + c] = false;
				}
			}		
		}		
	},
	
	getBestMaskPattern : function() {
	
		var minLostPoint = 0;
		var pattern = 0;
	
		for (var i = 0; i < 8; i++) {
			
			this.makeImpl(true, i);
	
			var lostPoint = QRUtil.getLostPoint(this);
	
			if (i === 0 || minLostPoint >  lostPoint) {
				minLostPoint = lostPoint;
				pattern = i;
			}
		}
	
		return pattern;
	},
	
	createMovieClip : function(target_mc, instance_name, depth) {
	
		var qr_mc = target_mc.createEmptyMovieClip(instance_name, depth);
		var cs = 1;
	
		this.make();

		for (var row = 0; row < this.modules.length; row++) {
			
			var y = row * cs;
			
			for (var col = 0; col < this.modules[row].length; col++) {
	
				var x = col * cs;
				var dark = this.modules[row][col];
			
				if (dark) {
					qr_mc.beginFill(0, 100);
					qr_mc.moveTo(x, y);
					qr_mc.lineTo(x + cs, y);
					qr_mc.lineTo(x + cs, y + cs);
					qr_mc.lineTo(x, y + cs);
					qr_mc.endFill();
				}
			}
		}
		
		return qr_mc;
	},

	setupTimingPattern : function() {
		
		for (var r = 8; r < this.moduleCount - 8; r++) {
			if (this.modules[r][6] !== null) {
				continue;
			}
			this.modules[r][6] = (r % 2 === 0);
		}
	
		for (var c = 8; c < this.moduleCount - 8; c++) {
			if (this.modules[6][c] !== null) {
				continue;
			}
			this.modules[6][c] = (c % 2 === 0);
		}
	},
	
	setupPositionAdjustPattern : function() {
	
		var pos = QRUtil.getPatternPosition(this.typeNumber);
		
		for (var i = 0; i < pos.length; i++) {
		
			for (var j = 0; j < pos.length; j++) {
			
				var row = pos[i];
				var col = pos[j];
				
				if (this.modules[row][col] !== null) {
					continue;
				}
				
				for (var r = -2; r <= 2; r++) {
				
					for (var c = -2; c <= 2; c++) {
					
						if (Math.abs(r) === 2 || 
                            Math.abs(c) === 2 ||
                            (r === 0 && c === 0) ) {
							this.modules[row + r][col + c] = true;
						} else {
							this.modules[row + r][col + c] = false;
						}
					}
				}
			}
		}
	},
	
	setupTypeNumber : function(test) {
	
		var bits = QRUtil.getBCHTypeNumber(this.typeNumber);
        var mod;
	
		for (var i = 0; i < 18; i++) {
			mod = (!test && ( (bits >> i) & 1) === 1);
			this.modules[Math.floor(i / 3)][i % 3 + this.moduleCount - 8 - 3] = mod;
		}
	
		for (var x = 0; x < 18; x++) {
			mod = (!test && ( (bits >> x) & 1) === 1);
			this.modules[x % 3 + this.moduleCount - 8 - 3][Math.floor(x / 3)] = mod;
		}
	},
	
	setupTypeInfo : function(test, maskPattern) {
	
		var data = (this.errorCorrectLevel << 3) | maskPattern;
		var bits = QRUtil.getBCHTypeInfo(data);
        var mod;
	
		// vertical		
		for (var v = 0; v < 15; v++) {
	
			mod = (!test && ( (bits >> v) & 1) === 1);
	
			if (v < 6) {
				this.modules[v][8] = mod;
			} else if (v < 8) {
				this.modules[v + 1][8] = mod;
			} else {
				this.modules[this.moduleCount - 15 + v][8] = mod;
			}
		}
	
		// horizontal
		for (var h = 0; h < 15; h++) {
	
			mod = (!test && ( (bits >> h) & 1) === 1);
			
			if (h < 8) {
				this.modules[8][this.moduleCount - h - 1] = mod;
			} else if (h < 9) {
				this.modules[8][15 - h - 1 + 1] = mod;
			} else {
				this.modules[8][15 - h - 1] = mod;
			}
		}
	
		// fixed module
		this.modules[this.moduleCount - 8][8] = (!test);
	
	},
	
	mapData : function(data, maskPattern) {
		
		var inc = -1;
		var row = this.moduleCount - 1;
		var bitIndex = 7;
		var byteIndex = 0;
		
		for (var col = this.moduleCount - 1; col > 0; col -= 2) {
	
			if (col === 6) col--;
	
			while (true) {
	
				for (var c = 0; c < 2; c++) {
					
					if (this.modules[row][col - c] === null) {
						
						var dark = false;
	
						if (byteIndex < data.length) {
							dark = ( ( (data[byteIndex] >>> bitIndex) & 1) === 1);
						}
	
						var mask = QRUtil.getMask(maskPattern, row, col - c);
	
						if (mask) {
							dark = !dark;
						}
						
						this.modules[row][col - c] = dark;
						bitIndex--;
	
						if (bitIndex === -1) {
							byteIndex++;
							bitIndex = 7;
						}
					}
				}
								
				row += inc;
	
				if (row < 0 || this.moduleCount <= row) {
					row -= inc;
					inc = -inc;
					break;
				}
			}
		}
		
	}

};

QRCode.PAD0 = 0xEC;
QRCode.PAD1 = 0x11;

QRCode.createData = function(typeNumber, errorCorrectLevel, dataList) {
	
	var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectLevel);
	
	var buffer = new QRBitBuffer();
	
	for (var i = 0; i < dataList.length; i++) {
		var data = dataList[i];
		buffer.put(data.mode, 4);
		buffer.put(data.getLength(), QRUtil.getLengthInBits(data.mode, typeNumber) );
		data.write(buffer);
	}

	// calc num max data.
	var totalDataCount = 0;
	for (var x = 0; x < rsBlocks.length; x++) {
		totalDataCount += rsBlocks[x].dataCount;
	}

	if (buffer.getLengthInBits() > totalDataCount * 8) {
		throw new Error("code length overflow. (" + 
            buffer.getLengthInBits() + 
            ">" +  
            totalDataCount * 8 + 
            ")");
	}

	// end code
	if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
		buffer.put(0, 4);
	}

	// padding
	while (buffer.getLengthInBits() % 8 !== 0) {
		buffer.putBit(false);
	}

	// padding
	while (true) {
		
		if (buffer.getLengthInBits() >= totalDataCount * 8) {
			break;
		}
		buffer.put(QRCode.PAD0, 8);
		
		if (buffer.getLengthInBits() >= totalDataCount * 8) {
			break;
		}
		buffer.put(QRCode.PAD1, 8);
	}

	return QRCode.createBytes(buffer, rsBlocks);
};

QRCode.createBytes = function(buffer, rsBlocks) {

	var offset = 0;
	
	var maxDcCount = 0;
	var maxEcCount = 0;
	
	var dcdata = new Array(rsBlocks.length);
	var ecdata = new Array(rsBlocks.length);
	
	for (var r = 0; r < rsBlocks.length; r++) {

		var dcCount = rsBlocks[r].dataCount;
		var ecCount = rsBlocks[r].totalCount - dcCount;

		maxDcCount = Math.max(maxDcCount, dcCount);
		maxEcCount = Math.max(maxEcCount, ecCount);
		
		dcdata[r] = new Array(dcCount);
		
		for (var i = 0; i < dcdata[r].length; i++) {
			dcdata[r][i] = 0xff & buffer.buffer[i + offset];
		}
		offset += dcCount;
		
		var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
		var rawPoly = new QRPolynomial(dcdata[r], rsPoly.getLength() - 1);

		var modPoly = rawPoly.mod(rsPoly);
		ecdata[r] = new Array(rsPoly.getLength() - 1);
		for (var x = 0; x < ecdata[r].length; x++) {
            var modIndex = x + modPoly.getLength() - ecdata[r].length;
			ecdata[r][x] = (modIndex >= 0)? modPoly.get(modIndex) : 0;
		}

	}
	
	var totalCodeCount = 0;
	for (var y = 0; y < rsBlocks.length; y++) {
		totalCodeCount += rsBlocks[y].totalCount;
	}

	var data = new Array(totalCodeCount);
	var index = 0;

	for (var z = 0; z < maxDcCount; z++) {
		for (var s = 0; s < rsBlocks.length; s++) {
			if (z < dcdata[s].length) {
				data[index++] = dcdata[s][z];
			}
		}
	}

	for (var xx = 0; xx < maxEcCount; xx++) {
		for (var t = 0; t < rsBlocks.length; t++) {
			if (xx < ecdata[t].length) {
				data[index++] = ecdata[t][xx];
			}
		}
	}

	return data;

};

module.exports = QRCode;

};
const QRCode = __qrRequire("index");
const QRErrorCorrectLevel=__qrRequire("QRErrorCorrectLevel");
const PORT = Number(process.env.PORT || 3000);
const rooms = new Map();
const MAX_PLAYERS = 19;
const ROOM_TTL = 1000 * 60 * 60 * 5;
const now = () => Date.now();
const rand = n => crypto.randomBytes(n).toString('hex');
const validRoom = x => /^[A-Z2-9]{6}$/.test(x || '');
function roomCode() { let v; do { v = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'.split('').sort(()=>Math.random()-.5).slice(0,6).join(''); } while(rooms.has(v)); return v; }
function send(res, code, value) {
  res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(value));
}
function error(res, code, message) { send(res, code, {error:message}); }
function parseBody(req) { return new Promise((resolve,reject)=>{let raw=''; req.on('data',d=>{raw+=d;if(raw.length>4096){reject(new Error('요청 데이터가 너무 큽니다.'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'));}catch{reject(new Error('요청 형식이 올바르지 않습니다.'));}});req.on('error',reject);}); }
function roomFor(code) { const r=rooms.get(code); return r && now()-r.lastSeen<ROOM_TTL ? r : null; }
function auth(r, token) {if(token && token===r.hostToken)return {type:'host'};const p=r.players.find(x=>x.token===token);return p?{type:'player',player:p}:null;}
function rank(r) { const active = r.eligible ? r.players.filter(p=>r.eligible.includes(p.id)):r.players; return active.slice().sort((a,b)=>b.score-a.score || a.joined-b.joined).map((p,i)=>({id:p.id,name:p.name,score:p.score,place:1+active.filter(o=>o.score>p.score).length,active:true})); }
function publicState(r, who) { return {room:r.code,phase:r.phase,round:r.round,duration:r.duration,configuredDuration:r.configuredDuration,startAt:r.startAt,endAt:r.endAt,serverNow:now(),isHost:who.type==='host',selfId:who.player?.id||null,players:r.players.map(p=>({id:p.id,name:p.name,score:p.score,active:!r.eligible||r.eligible.includes(p.id)})),ranking:rank(r),maxPlayers:MAX_PLAYERS}; }
function publish(r) {for(const client of r.clients){try{client.res.write(`event: state\ndata: ${JSON.stringify(publicState(r,client.who))}\n\n`);}catch{r.clients.delete(client);}}}
function advance(r) {const t=now();if(r.phase==='countdown' && t>=r.startAt){r.phase='running';publish(r);}if(r.phase==='running'&&t>=r.endAt){r.phase='finished';publish(r);}}
function svgQR(url) {
  const qr = new QRCode(0,QRErrorCorrectLevel.M); qr.addData(url);qr.make();const n=qr.getModuleCount(); const cells=[];
  for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(qr.isDark(r,c))cells.push(`<rect x="${c+4}" y="${r+4}" width="1" height="1"/>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n+8} ${n+8}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/><g fill="#091025">${cells.join('')}</g></svg>`;
}
const __ASSETS = {
"index.html":Buffer.from("PCFkb2N0eXBlIGh0bWw+PGh0bWwgbGFuZz0ia28iPjxoZWFkPjxtZXRhIGNoYXJzZXQ9InV0Zi04Ij48bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLGluaXRpYWwtc2NhbGU9MSxtYXhpbXVtLXNjYWxlPTEsdXNlci1zY2FsYWJsZT1ubyI+PG1ldGEgbmFtZT0idGhlbWUtY29sb3IiIGNvbnRlbnQ9IiMwQzEwMjMiPjxtZXRhIG5hbWU9ImRlc2NyaXB0aW9uIiBjb250ZW50PSIyMDI3IO2WieyatOydmCDsp4jso7whIOy5nOq1rOuTpOqzvCDtlajqu5gg7KaQ6riw64qUIOuqqOuwlOydvCDsi6Tsi5zqsIQg7YSw7LmYIOuLrOumrOq4sCDqsozsnoQiPjx0aXRsZT4yMDI3IO2WieyatOydmCDsp4jso7wgfCBUQVAgUlVOPC90aXRsZT48bGluayByZWw9InN0eWxlc2hlZXQiIGhyZWY9Ii9zdHlsZS5jc3MiPjwvaGVhZD4KPGJvZHk+PGRpdiBjbGFzcz0iYXBwIj4KICA8aGVhZGVyIGNsYXNzPSJicmFuZCI+PGRpdiBjbGFzcz0iYnJhbmQtYm9sdCI+4pqhPC9kaXY+PGRpdj48ZGl2IGNsYXNzPSJleWVicm93Ij4yMDI3IE5FVyBZRUFSIEdBTUU8L2Rpdj48c3Ryb25nPlRBUCBSVU4gPHNwYW4+MjAyNzwvc3Bhbj48L3N0cm9uZz48L2Rpdj48c3BhbiBjbGFzcz0iYnJhbmQtdGFnIj5MSVZFIFJBQ0U8L3NwYW4+PC9oZWFkZXI+CiAgPG1haW4gaWQ9ImFwcCI+PHNlY3Rpb24gY2xhc3M9IndlbGNvbWUgY2FyZCI+PGRpdiBjbGFzcz0iYmlnLWVtb2ppIj7wn4+D4oCN4pmA77iP8J+SqDwvZGl2PjxkaXYgY2xhc3M9ImV5ZWJyb3ciPuuqqOuRkCDtlajqu5gg64us66as64qUIOyLoOuFhCDsnbTrsqTtirg8L2Rpdj48aDE+7IaQ6rCA65297J20IOu5oOultOuptDxicj48ZW0+7Jqw7Iq57J2AIOuCtCDqsoMhPC9lbT48L2gxPjxwPu2ctOuMgO2PsCDtmZTrqbTsnYQg65GQ65Oc66CkIDE566qF7J20IOyLpOyLnOqwhOycvOuhnCDri6zroKTsmpQuPC9wPjxidXR0b24gY2xhc3M9ImJ0biBwcmltYXJ5IGZ1bGwiIGlkPSJjcmVhdGUiPvCfjqQg64K0IO2ctOuMgO2PsOycvOuhnCDqsr3quLAg7KO87LWc7ZWY6riwPC9idXR0b24+PGRpdiBjbGFzcz0ic2VwYXJhdG9yIj7rmJDripQ8L2Rpdj48bGFiZWwgY2xhc3M9ImZpZWxkLWxhYmVsIj7ssLjqsIDtlaAg6rK96riw67CpIOy9lOuTnDwvbGFiZWw+PGRpdiBjbGFzcz0iaW5saW5lIj48aW5wdXQgY2xhc3M9ImlucHV0IiBpZD0ibWFudWFsUm9vbSIgcGxhY2Vob2xkZXI9IuyYiDogQTdCMkNEIiBtYXhsZW5ndGg9IjYiIGF1dG9jYXBpdGFsaXplPSJjaGFyYWN0ZXJzIi8+PGJ1dHRvbiBjbGFzcz0iYnRuIGxpZ2h0IiBpZD0iZW50ZXJSb29tIj7ssLjqsIDtlZjquLA8L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9tYWluPgogIDxmb290ZXIgY2xhc3M9ImZvb3QiPuyEnOuhnCDri6Trpbgg7Zy064yA7Y+w7Jy866GcIOygkeyGje2VmOuKlCAxOeuqhSDrqYDti7DtlIzroIjsnbQg6rKM7J6EPC9mb290ZXI+CjwvZGl2PjxkaXYgaWQ9InRvYXN0IiByb2xlPSJzdGF0dXMiIGFyaWEtbGl2ZT0icG9saXRlIj48L2Rpdj48c2NyaXB0IHNyYz0iL2FwcC5qcyIgZGVmZXI+PC9zY3JpcHQ+PC9ib2R5PjwvaHRtbD4K","base64"),
"app.js":Buffer.from("J3VzZSBzdHJpY3QnOwpjb25zdCByb290PWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNhcHAnKSwgdG9hc3RCb3g9ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3RvYXN0Jyk7CmNvbnN0ICQ9aWQ9PmRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTsKY29uc3QgZXNjYXBlSFRNTD1zPT5TdHJpbmcocz8/JycpLnJlcGxhY2UoL1smPD4iJ10vZyxjPT4oeycmJzonJmFtcDsnLCc8JzonJmx0OycsJz4nOicmZ3Q7JywnIic6JyZxdW90OycsIiciOicmIzM5Oyd9W2NdKSk7CmxldCBtb2RlPSdob21lJyxyb29tPScnLHRva2VuPScnLHNlbGZJZD0nJyxzdGF0ZT1udWxsLHN0cmVhbT1udWxsLGNsb2NrT2Zmc2V0PTAsbGFzdExheW91dD0nJyxsb2NhbFRhcHM9MCxsYXN0U2VudD0wLHNlbmRpbmc9ZmFsc2U7CmxldCBzb3VuZEVuYWJsZWQ9dHJ1ZSx2b2x1bWU9LjM1LGF1ZGlvQ3R4PW51bGwsbXVzaWNUaW1lcj1udWxsLGJlYXRJbmRleD0wLHRvYXN0VGltZXI9bnVsbCxwcmV2UGhhc2U9JycscHJldlJvdW5kPTA7CmZ1bmN0aW9uIHRvYXN0KG1zZyl7dG9hc3RCb3gudGV4dENvbnRlbnQ9bXNnO3RvYXN0Qm94LmNsYXNzTGlzdC5hZGQoJ3Nob3cnKTtjbGVhclRpbWVvdXQodG9hc3RUaW1lcik7dG9hc3RUaW1lcj1zZXRUaW1lb3V0KCgpPT50b2FzdEJveC5jbGFzc0xpc3QucmVtb3ZlKCdzaG93JyksMjgwMCk7fQphc3luYyBmdW5jdGlvbiByZXF1ZXN0KHVybCxkYXRhKXtjb25zdCByPWF3YWl0IGZldGNoKHVybCx7bWV0aG9kOidQT1NUJyxoZWFkZXJzOnsnQ29udGVudC1UeXBlJzonYXBwbGljYXRpb24vanNvbid9LGJvZHk6SlNPTi5zdHJpbmdpZnkoZGF0YSl9KTtjb25zdCBqPWF3YWl0IHIuanNvbigpO2lmKCFyLm9rKXRocm93IEVycm9yKGouZXJyb3J8fCfsl7DqsrDsl5Ag7Iuk7Yyo7ZaI7Iq164uI64ukLicpO3JldHVybiBqO30KZnVuY3Rpb24gc2hhcmVVcmwoKXtyZXR1cm4gbmV3IFVSTChgLz9yb29tPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJvb20pfWAsbG9jYXRpb24ub3JpZ2luKS5ocmVmO30KZnVuY3Rpb24gaG9tZSgpe21vZGU9J2hvbWUnO3Jvb209Jyc7dG9rZW49Jyc7c3RhdGU9bnVsbDtjbG9zZVN0cmVhbSgpO2hpc3RvcnkucmVwbGFjZVN0YXRlKG51bGwsJycsJy8nKTtyb290LmlubmVySFRNTD0nPHNlY3Rpb24gY2xhc3M9IndlbGNvbWUgY2FyZCI+PGRpdiBjbGFzcz0iYmlnLWVtb2ppIj7wn4+D4oCN4pmA77iP8J+SqDwvZGl2PjxkaXYgY2xhc3M9ImV5ZWJyb3ciPuuqqOuRkCDtlajqu5gg64us66as64qUIOyLoOuFhCDsnbTrsqTtirg8L2Rpdj48aDE+7IaQ6rCA65297J20IOu5oOultOuptDxicj48ZW0+7Jqw7Iq57J2AIOuCtCDqsoMhPC9lbT48L2gxPjxwPu2ctOuMgO2PsCDtmZTrqbTsnYQg65GQ65Oc66CkIDE566qF7J20IOyLpOyLnOqwhOycvOuhnCDri6zroKTsmpQuPC9wPjxidXR0b24gY2xhc3M9ImJ0biBwcmltYXJ5IGZ1bGwiIGRhdGEtYWN0aW9uPSJjcmVhdGUiPvCfjqQg64K0IO2ctOuMgO2PsOycvOuhnCDqsr3quLAg7KO87LWc7ZWY6riwPC9idXR0b24+PGRpdiBjbGFzcz0ic2VwYXJhdG9yIj7rmJDripQ8L2Rpdj48bGFiZWwgY2xhc3M9ImZpZWxkLWxhYmVsIj7ssLjqsIDtlaAg6rK96riw67CpIOy9lOuTnDwvbGFiZWw+PGRpdiBjbGFzcz0iaW5saW5lIj48aW5wdXQgY2xhc3M9ImlucHV0IiBpZD0ibWFudWFsUm9vbSIgcGxhY2Vob2xkZXI9IuyYiDogQTdCMkNEIiBtYXhsZW5ndGg9IjYiIGF1dG9jYXBpdGFsaXplPSJjaGFyYWN0ZXJzIi8+PGJ1dHRvbiBjbGFzcz0iYnRuIGxpZ2h0IiBkYXRhLWFjdGlvbj0iZW50ZXIiPuywuOqwgO2VmOq4sDwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj4nO30KZnVuY3Rpb24gam9pblNjcmVlbihjb2RlKXttb2RlPSdqb2luaW5nJztyb29tPWNvZGUudG9VcHBlckNhc2UoKTtoaXN0b3J5LnJlcGxhY2VTdGF0ZShudWxsLCcnLGAvP3Jvb209JHtyb29tfWApO2Nsb3NlU3RyZWFtKCk7cm9vdC5pbm5lckhUTUw9YDxzZWN0aW9uIGNsYXNzPSJjYXJkIj48c3BhbiBjbGFzcz0icGlsbCI+8J+PgSDqsr3quLDrsKkgJHtlc2NhcGVIVE1MKHJvb20pfTwvc3Bhbj48aDEgc3R5bGU9ImZvbnQtc2l6ZTozMHB4Ij7tlonsmrTsnZgg7KeI7KO87JeQPGJyPjxlbT7ssLjqsIDtlZjquLA8L2VtPjwvaDE+PHA+6rK96riw7JeQIO2RnOyLnOuQoCDsnbTrpoTsnYQg7J6F66Cl7ZW0IOyjvOyEuOyalC48L3A+PGxhYmVsIGNsYXNzPSJmaWVsZC1sYWJlbCI+64K0IOydtOumhCDrmJDripQg64uJ64Sk7J6EPC9sYWJlbD48aW5wdXQgY2xhc3M9ImlucHV0IiBpZD0ibmlja25hbWUiIHBsYWNlaG9sZGVyPSLsmIg6IOuvuO2eiCIgbWF4bGVuZ3RoPSIxNiIgYXV0b2NvbXBsZXRlPSJuaWNrbmFtZSIgdmFsdWU9IiR7ZXNjYXBlSFRNTChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndGFwcnVuOm5pY2tuYW1lJyl8fCcnKX0iLz48ZGl2IGNsYXNzPSJzZWN0aW9uIj48YnV0dG9uIGNsYXNzPSJidG4gcHJpbWFyeSBmdWxsIiBkYXRhLWFjdGlvbj0iam9pbiI+8J+agCDqsr3quLDrsKkg7J6F7J6l7ZWY6riwPC9idXR0b24+PC9kaXY+PHAgY2xhc3M9InNtYWxsIj7qsr3quLDrsKnri7kg7LWc64yAIDE566qF6rmM7KeAIOywuOqwgO2VoCDsiJgg7J6I7Ja07JqULjwvcD48L3NlY3Rpb24+YDt9CmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVJvb20oKXt0cnl7Y29uc3Qgaj1hd2FpdCByZXF1ZXN0KCcvYXBpL2NyZWF0ZScse30pO21vZGU9J2hvc3QnO3Jvb209ai5yb29tO3Rva2VuPWouaG9zdFRva2VuO2xvY2FsU3RvcmFnZS5zZXRJdGVtKGB0YXBydW46aG9zdDoke3Jvb219YCx0b2tlbik7bG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RhcHJ1bjpsYXN0SG9zdCcscm9vbSk7aGlzdG9yeS5yZXBsYWNlU3RhdGUobnVsbCwnJyxgLz9ob3N0PSR7cm9vbX1gKTtjb25uZWN0KCk7fWNhdGNoKGUpe3RvYXN0KGUubWVzc2FnZSk7fX0KYXN5bmMgZnVuY3Rpb24gam9pblJvb20oKXtjb25zdCBuYW1lPSgkKCduaWNrbmFtZScpPy52YWx1ZXx8JycpLnRyaW0oKTtpZighbmFtZSl7dG9hc3QoJ+ydtOumhOydhCDsnoXroKXtlbQg7KO87IS47JqULicpO3JldHVybjt9dHJ5e2NvbnN0IGo9YXdhaXQgcmVxdWVzdCgnL2FwaS9qb2luJyx7cm9vbSxuYW1lfSk7dG9rZW49ai5wbGF5ZXJUb2tlbjtzZWxmSWQ9ai5wbGF5ZXJJZDttb2RlPSdwbGF5ZXInO2xvY2FsU3RvcmFnZS5zZXRJdGVtKGB0YXBydW46cGxheWVyOiR7cm9vbX1gLHRva2VuKTtsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGFwcnVuOm5pY2tuYW1lJyxuYW1lKTtjb25uZWN0KCk7fWNhdGNoKGUpe3RvYXN0KGUubWVzc2FnZSk7fX0KZnVuY3Rpb24gY2xvc2VTdHJlYW0oKXtpZihzdHJlYW0pe3N0cmVhbS5jbG9zZSgpO3N0cmVhbT1udWxsO319CmZ1bmN0aW9uIGNvbm5lY3QoKXtjbG9zZVN0cmVhbSgpO3Jvb3QuaW5uZXJIVE1MPSc8c2VjdGlvbiBjbGFzcz0iY2FyZCBlbXB0eSI+6rK96riw67Cp7JeQIOyXsOqysO2VmOqzoCDsnojslrTsmpTigKY8L3NlY3Rpb24+JztzdHJlYW09bmV3IEV2ZW50U291cmNlKGAvYXBpL3N0cmVhbT9yb29tPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJvb20pfSZ0b2tlbj0ke2VuY29kZVVSSUNvbXBvbmVudCh0b2tlbil9YCk7c3RyZWFtLmFkZEV2ZW50TGlzdGVuZXIoJ3N0YXRlJyxlPT57Y29uc3Qgcz1KU09OLnBhcnNlKGUuZGF0YSk7Y2xvY2tPZmZzZXQ9cy5zZXJ2ZXJOb3ctRGF0ZS5ub3coKTtjb25zdCBsYXlvdXQ9YCR7cy5waGFzZX06JHtzLnJvdW5kfToke3MuaXNIb3N0fToke3MucGxheWVycy5tYXAocD0+cC5pZCkuam9pbignLCcpfWA7c3RhdGU9cztzZWxmSWQ9cy5zZWxmSWR8fHNlbGZJZDtpZihzLnJvdW5kIT09cHJldlJvdW5kfHwocHJldlBoYXNlPT09J2ZpbmlzaGVkJyYmcy5waGFzZT09PSd3YWl0aW5nJykpe2xvY2FsVGFwcz0wO2xhc3RTZW50PTA7cHJldlJvdW5kPXMucm91bmQ7fWlmKGxheW91dCE9PWxhc3RMYXlvdXQpe2xhc3RMYXlvdXQ9bGF5b3V0O3JlbmRlcigpO311cGRhdGVMaXZlKCk7aWYobW9kZT09PSdob3N0Jyl7aWYocy5waGFzZT09PSdydW5uaW5nJyYmcHJldlBoYXNlIT09J3J1bm5pbmcnKXN0YXJ0TXVzaWMoKTtpZihzLnBoYXNlPT09J2ZpbmlzaGVkJyYmcHJldlBoYXNlIT09J2ZpbmlzaGVkJylzdG9wTXVzaWMoKTt9cHJldlBoYXNlPXMucGhhc2U7fSk7c3RyZWFtLm9uZXJyb3I9KCk9PntpZihtb2RlIT09J2hvbWUnKXRvYXN0KCfsl7DqsrDsnbQg67aI7JWI7KCV7ZWp64uI64ukLiDsnpDrj5kg7J6s7Jew6rKwIOykkeKApicpO307fQpmdW5jdGlvbiBob3N0Q2FyZCgpe2NvbnN0IHM9c3RhdGUscGxheWVycz1zLnBsYXllcnMsd2FpdGluZz1zLnBoYXNlPT09J3dhaXRpbmcnO2xldCBtaWRkbGU9Jyc7CiBpZih3YWl0aW5nKXttaWRkbGU9YDxzZWN0aW9uIGNsYXNzPSJjYXJkIj48ZGl2IGNsYXNzPSJyb3ciPjxkaXY+PGRpdiBjbGFzcz0iZXllYnJvdyI+SU5WSVRBVElPTjwvZGl2PjxoMiBjbGFzcz0iaDIiPlFS66GcIOuwlOuhnCDsnoXsnqU8L2gyPjwvZGl2PjxzcGFuIGNsYXNzPSJ0YWciPiR7ZXNjYXBlSFRNTChyb29tKX08L3NwYW4+PC9kaXY+PGRpdiBjbGFzcz0icXItd3JhcCI+PGltZyBpZD0icXJJbWFnZSIgYWx0PSLssLjqsIDsmqkgUVIg7L2U65OcIiBzcmM9Ii9hcGkvcXIuc3ZnP3Jvb209JHtlbmNvZGVVUklDb21wb25lbnQocm9vbSl9IiAvPjwvZGl2PjxkaXYgY2xhc3M9Imludi11cmwiIGlkPSJ1cmxWYWx1ZSI+JHtlc2NhcGVIVE1MKHNoYXJlVXJsKCkpfTwvZGl2PjxkaXYgY2xhc3M9ImJ1dHRvbnMgc2VjdGlvbiIgc3R5bGU9Im1hcmdpbi10b3A6MTBweCI+PGJ1dHRvbiBjbGFzcz0iYnRuIGxpZ2h0IiBkYXRhLWFjdGlvbj0iY29weSI+8J+UlyDrp4Htgawg67O17IKsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz0iYnRuIHByaW1hcnkiIGRhdGEtYWN0aW9uPSJzaGFyZSI+8J+SrCDrp4Htgawg6rO17JygPC9idXR0b24+PC9kaXY+PHAgY2xhc3M9ImhpbnQiPlFS7J2AIOuLpOuluCDtnLTrjIDtj7Ag7Lm066mU652866GcIOyKpOy6lO2VmOuptCDrj7zsmpQuIO2VnCDtnLTrjIDtj7DsnLzroZwg7KeE7ZaJ7ZWgIOuVjOuKlCDsubTsubTsmKTthqHsnLzroZwg66eB7YGsIOqzteycoOqwgCDrjZQg7Y6466as7ZWp64uI64ukLjwvcD48L3NlY3Rpb24+PHNlY3Rpb24gY2xhc3M9ImNhcmQiPjxoMiBjbGFzcz0iaDIiPuKPsSDqsr3quLAg7Iuc6rCEPC9oMj48cCBjbGFzcz0ic21hbGwiPuyLnOyekSDsoITsl5Ag7ISg7YOd7ZWY7IS47JqULjwvcD48ZGl2IGNsYXNzPSJzZWdtZW50Ij48YnV0dG9uIGRhdGEtYWN0aW9uPSJkdXJhdGlvbiIgZGF0YS12YWx1ZT0iNjAiIGNsYXNzPSIke3MuY29uZmlndXJlZER1cmF0aW9uPT09NjA/J2FjdGl2ZSc6Jyd9Ij42MOy0iCDCtyAx67aEPC9idXR0b24+PGJ1dHRvbiBkYXRhLWFjdGlvbj0iZHVyYXRpb24iIGRhdGEtdmFsdWU9IjEyMCIgY2xhc3M9IiR7cy5jb25maWd1cmVkRHVyYXRpb249PT0xMjA/J2FjdGl2ZSc6Jyd9Ij4xMjDstIggwrcgMuu2hDwvYnV0dG9uPjwvZGl2PjxkaXYgY2xhc3M9InNlY3Rpb24gcm93Ij48ZGl2PjxkaXYgY2xhc3M9ImxhYmVsIj7wn461IOynhO2WieyekCDrsLDqsr3snYzslYU8L2Rpdj48ZGl2IGNsYXNzPSJoaW50Ij7ssLjqsIDsnpAg7Zy064yA7Y+w7JeQ7ISc64qUIOyerOyDneuQmOyngCDslYrslYTsmpQuPC9kaXY+PC9kaXY+PGRpdiBkYXRhLWFjdGlvbj0ic291bmQiIGNsYXNzPSJ0b2dnbGUgJHtzb3VuZEVuYWJsZWQ/J29uJzonJ30iIHJvbGU9InN3aXRjaCIgYXJpYS1jaGVja2VkPSIke3NvdW5kRW5hYmxlZH0iIHRhYmluZGV4PSIwIj48L2Rpdj48L2Rpdj48aW5wdXQgaWQ9InZvbHVtZSIgY2xhc3M9InJhbmdlIiBhcmlhLWxhYmVsPSLsnYzslYUg7J2M65+JIiB0eXBlPSJyYW5nZSIgbWluPSIwIiBtYXg9IjEwMCIgdmFsdWU9IiR7TWF0aC5yb3VuZCh2b2x1bWUqMTAwKX0iLz48YnV0dG9uIGNsYXNzPSJidG4gb3V0bGluZWQgZnVsbCIgZGF0YS1hY3Rpb249InByZXZpZXciPuKZqyDsnYzslYUgM+y0iCDrr7jrpqzrk6PquLA8L2J1dHRvbj48L3NlY3Rpb24+YDt9CiBlbHNlIGlmKHMucGhhc2U9PT0nZmluaXNoZWQnKXttaWRkbGU9cmVzdWx0c0hUTUwodHJ1ZSk7fQogZWxzZXttaWRkbGU9YDxzZWN0aW9uIGNsYXNzPSJjYXJkIj48ZGl2IGNsYXNzPSJyYWNlLXRvcCI+PHNwYW4gY2xhc3M9InBpbGwiPiR7cy5yb3VuZD09PTI/J/CflKUg64+Z7KCQIOqysOyKueyghCc6J+KaoSDsi6Tsi5zqsIQg6rK96riwJ308L3NwYW4+PGRpdiBpZD0iaG9zdFRpbWVyIiBjbGFzcz0idGltZSI+JHtzLmR1cmF0aW9ufTwvZGl2PjxkaXYgaWQ9InBoYXNlTGFiZWwiIGNsYXNzPSJzbWFsbCI+7KSA67mEIOykkeKApjwvZGl2PjwvZGl2PjxkaXYgY2xhc3M9InByb2dyZXNzIHNlY3Rpb24iPjxpIGlkPSJ0aW1lUHJvZ3Jlc3MiIHN0eWxlPSJ3aWR0aDowJSI+PC9pPjwvZGl2PjxkaXYgaWQ9InRyYWNrcyIgY2xhc3M9InNlY3Rpb24iPjwvZGl2Pjwvc2VjdGlvbj5gO30KIHJldHVybiBgPHNlY3Rpb24gY2xhc3M9ImNhcmQiPjxkaXYgY2xhc3M9InJvdyI+PGRpdj48ZGl2IGNsYXNzPSJleWVicm93Ij5IT1NUIENPTlRST0w8L2Rpdj48aDIgY2xhc3M9ImgyIj7wn46kIOynhO2WieyekCDtmZTrqbQ8L2gyPjwvZGl2PjxzcGFuIGNsYXNzPSJwaWxsIj4ke3dhaXRpbmc/J+ywuOqwgOyekCDrjIDquLAnOnMucGhhc2U9PT0nZmluaXNoZWQnPyfqsr3quLAg7KKF66OMJzpzLnBoYXNlPT09J2NvdW50ZG93bic/J+y2nOuwnCDspIDruYQnOifqsr3quLAg7KSRJ308L3NwYW4+PC9kaXY+PGRpdiBjbGFzcz0icm93IHNlY3Rpb24iPjxzcGFuIGNsYXNzPSJsYWJlbCI+7J6F7J6lIOyduOybkDwvc3Bhbj48c3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiR7cGxheWVycy5sZW5ndGh9PC9zcGFuPjxzcGFuIGNsYXNzPSJzbWFsbCI+IC8gMTnrqoU8L3NwYW4+PC9zcGFuPjwvZGl2PjxkaXYgY2xhc3M9ImNoaXBzIj4ke3BsYXllcnMubWFwKHA9PmA8c3BhbiBjbGFzcz0iY2hpcCI+JHtlc2NhcGVIVE1MKHAubmFtZSl9PC9zcGFuPmApLmpvaW4oJycpfHwnPHNwYW4gY2xhc3M9ImVtcHR5Ij7ssLjqsIDsnpAg7J6F7J6l7J2EIOq4sOuLpOumrOqzoCDsnojslrTsmpQuPC9zcGFuPid9PC9kaXY+PC9zZWN0aW9uPiR7bWlkZGxlfTxzZWN0aW9uIGNsYXNzPSJjYXJkIj4ke3dhaXRpbmc/YDxidXR0b24gY2xhc3M9ImJ0biBwcmltYXJ5IGZ1bGwiIGRhdGEtYWN0aW9uPSJzdGFydCIgJHtwbGF5ZXJzLmxlbmd0aD8nJzonZGlzYWJsZWQnfT7wn5qmICR7cy5yb3VuZD09PTI/JzEw7LSIIOqysOyKuSc6J+uzuCDqsr3quLAnfSDsi5zsnpHtlZjquLA8L2J1dHRvbj5gOnMucGhhc2U9PT0nZmluaXNoZWQnP2Ake3MucmFua2luZy5sZW5ndGg+MSYmcy5yYW5raW5nWzBdLnNjb3JlPT09cy5yYW5raW5nWzFdLnNjb3JlPyc8YnV0dG9uIGNsYXNzPSJidG4gcHJpbWFyeSBmdWxsIiBkYXRhLWFjdGlvbj0iZmluYWwiPvCflKUg6rO164+ZIDHsnIQgMTDstIgg6rKw7Iq57KCEPC9idXR0b24+JzonJ308YnV0dG9uIGNsYXNzPSJidG4gc2Vjb25kYXJ5IGZ1bGwiIHN0eWxlPSJtYXJnaW4tdG9wOjEwcHgiIGRhdGEtYWN0aW9uPSJyZXNldCI+4oa7IOuLpOyLnCDqsr3quLDtlZjquLA8L2J1dHRvbj5gOmA8ZGl2IGNsYXNzPSJub3RpY2UiPuynhO2WiSDspJHsl5DripQg6rKM7J6EIOyLnOqwhOydhCDrs4Dqsr3tlaAg7IiYIOyXhuyWtOyalC4g7LC46rCA7J6Q65Ok7J20IO2Dre2VmOuKlCDrj5nslYgg7Iuk7Iuc6rCEIOyInOychOqwgCDtkZzsi5zrkKnri4jri6QuPC9kaXY+YH08ZGl2IGNsYXNzPSJzZWN0aW9uIj48YnV0dG9uIGNsYXNzPSJidG4gb3V0bGluZWQgZnVsbCIgZGF0YS1hY3Rpb249ImhvbWUiPu2ZiOycvOuhnCDrj4zslYTqsIDquLA8L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+YDsKfQpmdW5jdGlvbiBwbGF5ZXJDYXJkKCl7Y29uc3Qgcz1zdGF0ZSxtZT1zLnBsYXllcnMuZmluZChwPT5wLmlkPT09c2VsZklkKTtjb25zdCBlbGlnaWJsZT0hcy5lbGlnaWJsZXx8cy5wbGF5ZXJzLmZpbmQocD0+cC5pZD09PXNlbGZJZCk/LmFjdGl2ZTsKIGlmKHMucGhhc2U9PT0nZmluaXNoZWQnKXJldHVybiByZXN1bHRzSFRNTChmYWxzZSk7CiBpZihzLnBoYXNlPT09J3dhaXRpbmcnKXJldHVybiBgPHNlY3Rpb24gY2xhc3M9IndlbGNvbWUgY2FyZCI+PGRpdiBjbGFzcz0iYmlnLWVtb2ppIj7wn4+BPC9kaXY+PGRpdiBjbGFzcz0iZXllYnJvdyI+UkFDRSBXQUlUSU5HIFJPT008L2Rpdj48aDE+JHtlc2NhcGVIVE1MKG1lPy5uYW1lfHwn7LC46rCA7J6QJyl964uYLDxicj48ZW0+7J6F7J6lIOyZhOujjCE8L2VtPjwvaDE+PHA+7KeE7ZaJ7J6Q6rCAIOqyveq4sOulvCDsi5zsnpHtlaAg65WM6rmM7KeAPGJyPu2ZlOuptOydhCDsvJzrkZDqs6Ag6riw64uk66CkIOyjvOyEuOyalC48L3A+PGRpdiBjbGFzcz0icm93Ij48c3BhbiBjbGFzcz0ibGFiZWwiPuywuOqwgCDsnbjsm5A8L3NwYW4+PHN0cm9uZyBjbGFzcz0iY291bnQiPiR7cy5wbGF5ZXJzLmxlbmd0aH0gLyAxOTwvc3Ryb25nPjwvZGl2PjxkaXYgY2xhc3M9ImRpdmlkZXIiPjwvZGl2PjxkaXYgY2xhc3M9InJvdyI+PHNwYW4gY2xhc3M9ImxhYmVsIj7qsr3quLAg7Iuc6rCEPC9zcGFuPjxzcGFuIGNsYXNzPSJ0YWciPiR7cy5kdXJhdGlvbn3stIg8L3NwYW4+PC9kaXY+JHtzLnJvdW5kPT09MiYmIWVsaWdpYmxlPyc8cD7snbTrsoggMTDstIgg6rKw7Iq57J2AIOqzteuPmSAx7JyEIOywuOqwgOyekOunjCDtg63tlaAg7IiYIOyeiOyWtOyalC48L3A+JzonJ308L3NlY3Rpb24+YDsKIHJldHVybiBgPHNlY3Rpb24gY2xhc3M9ImNhcmQiPjxkaXYgY2xhc3M9ImV5ZWJyb3ciPiR7cy5yb3VuZD09PTI/J1RJRSBCUkVBSyBGSU5BTCc6J1RBUCBBUyBGQVNUIEFTIFlPVSBDQU4nfTwvZGl2PjxoMiBjbGFzcz0iaDIiPvCfj4MgJHtlc2NhcGVIVE1MKG1lPy5uYW1lfHwn64KYJyl97J2YIOugiOydtOyKpDwvaDI+PGRpdiBjbGFzcz0icm93IHNlY3Rpb24iPjxkaXY+PGRpdiBjbGFzcz0ic21hbGwiPuuCqOydgCDsi5zqsIQ8L2Rpdj48ZGl2IGlkPSJwbGF5ZXJUaW1lciIgY2xhc3M9InRpbWUiPiR7cy5kdXJhdGlvbn08L2Rpdj48L2Rpdj48ZGl2IHN0eWxlPSJ0ZXh0LWFsaWduOnJpZ2h0Ij48ZGl2IGNsYXNzPSJzbWFsbCI+64K0IO2EsOy5mDwvZGl2PjxkaXYgY2xhc3M9Im1lLWNvdW50IiBpZD0ibXlDb3VudCI+MDwvZGl2PjwvZGl2PjwvZGl2PjxkaXYgY2xhc3M9InByb2dyZXNzIj48aSBpZD0idGltZVByb2dyZXNzIiBzdHlsZT0id2lkdGg6MCUiPjwvaT48L2Rpdj4ke2VsaWdpYmxlPyc8YnV0dG9uIGlkPSJ0YXBab25lIiBjbGFzcz0idGFwLXpvbmUiIGRpc2FibGVkPjxzcGFuIGNsYXNzPSJoYW5kIj7wn5GGPC9zcGFuPjxzcGFuIGNsYXNzPSJ0YXAtdGl0bGUiPlRBUCEgVEFQITwvc3Bhbj48c3BhbiBjbGFzcz0idGFwLXN1YiI+7ZmU66m07J2EIOuvuOy5nCDrk6/snbQg7YSw7LmYITwvc3Bhbj48L2J1dHRvbj4nOic8cCBjbGFzcz0ibm90aWNlIj7snbTrsogg6rKw7Iq57KCE7J2AIOqzteuPmSAx7JyE66eMIOywuOyXrO2VoCDsiJgg7J6I7Ja07JqULjwvcD4nfTxkaXYgY2xhc3M9InJvdyI+PHNwYW4gY2xhc3M9ImxhYmVsIj7tmITsnqwg7Iic7JyEPC9zcGFuPjxzdHJvbmcgY2xhc3M9ImNvdW50IiBpZD0ibXlQbGFjZSI+LTwvc3Ryb25nPjwvZGl2PjxwIGNsYXNzPSJoaW50Ij7shpDqsIDrnb3snLzroZwg7LSI66Gd7IOJIOuyhO2KvOydhCDruaDrpbTqsowg64iM65+s7KO87IS47JqULiDtmZTrqbTsnYQg6ri46rKMIOuIhOultOuKlCDqsoPrs7Tri6Qg7Jew7IaNIO2DreydtCDsnKDrpqztlanri4jri6QuPC9wPjwvc2VjdGlvbj5gOwp9CmZ1bmN0aW9uIHJlc3VsdHNIVE1MKGhvc3Qpe2NvbnN0IHM9c3RhdGUscmFuaz1zLnJhbmtpbmcsdG9wPVtyYW5rLmZpbmQoeD0+eC5wbGFjZT09PTIpLHJhbmsuZmluZCh4PT54LnBsYWNlPT09MSkscmFuay5maW5kKHg9PngucGxhY2U9PT0zKV07cmV0dXJuIGA8c2VjdGlvbiBjbGFzcz0iY2FyZCI+PGRpdiBjbGFzcz0icmFjZS10b3AiPjxkaXYgY2xhc3M9ImV5ZWJyb3ciPlJBQ0UgRklOSVNIRUQ8L2Rpdj48ZGl2IGNsYXNzPSJiaWctZW1vamkiIHN0eWxlPSJmb250LXNpemU6NTJweCI+8J+PhjwvZGl2PjxoMiBjbGFzcz0iaDIiPiR7cy5yb3VuZD09PTI/JzEw7LSIIOqysOyKueyghCDqsrDqs7wnOifstZzsooUg6rK96riwIOqysOqzvCd9PC9oMj48cD7rgZ3quYzsp4Ag64us66awIOywuOqwgOyekCDrqqjrkZAg7IiY6rOg7ZaI7Ja07JqUITwvcD48L2Rpdj48ZGl2IGNsYXNzPSJwb2RpdW0iPiR7dG9wLm1hcCgocCxpKT0+YDxkaXYgY2xhc3M9InBlcnNvbiAke2k9PT0xPydmaXJzdCc6Jyd9Ij48ZGl2IGNsYXNzPSJtZWRhbCI+JHtbJ/CfpYgnLCfwn6WHJywn8J+liSddW2ldfTwvZGl2PjxkaXYgY2xhc3M9Im5hbWUiPiR7ZXNjYXBlSFRNTChwPy5uYW1lfHwn4oCUJyl9PC9kaXY+PGRpdiBjbGFzcz0icG9pbnRzIj4ke3A/YCR7cC5zY29yZX0g7YOtYDonICd9PC9kaXY+PC9kaXY+YCkuam9pbignJyl9PC9kaXY+PGgyIGNsYXNzPSJoMiIgc3R5bGU9ImZvbnQtc2l6ZToxN3B4Ij7wn5OKIOyghOyytCDsiJzsnIQ8L2gyPiR7cmFuay5tYXAocD0+YDxkaXYgY2xhc3M9InJlc3VsdC1yb3ciPjxzdHJvbmc+JHtwLnBsYWNlfeychCDCtyAke2VzY2FwZUhUTUwocC5uYW1lKX08L3N0cm9uZz48c3BhbiBjbGFzcz0ic2NvcmUiPiR7cC5zY29yZX0gVEFQPC9zcGFuPjwvZGl2PmApLmpvaW4oJycpfSR7aG9zdD8nJzonPHAgY2xhc3M9ImhpbnQiPuuPmeygkOyekOuKlCDqsJnsnYAg7Iic7JyE66GcIO2RnOyLnOuQqeuLiOuLpC48L3A+J308L3NlY3Rpb24+YDt9CmZ1bmN0aW9uIHJlbmRlcigpe2lmKCFzdGF0ZSlyZXR1cm47cm9vdC5pbm5lckhUTUw9bW9kZT09PSdob3N0Jz9ob3N0Q2FyZCgpOnBsYXllckNhcmQoKTt9CmZ1bmN0aW9uIHVwZGF0ZUxpdmUoKXtjb25zdCBzPXN0YXRlO2lmKCFzKXJldHVybjtjb25zdCB0PURhdGUubm93KCkrY2xvY2tPZmZzZXQscmVtYWluaW5nPXMucGhhc2U9PT0nZmluaXNoZWQnPzA6cy5waGFzZT09PSd3YWl0aW5nJz9zLmR1cmF0aW9uOnMucGhhc2U9PT0nY291bnRkb3duJz8ocy5zdGFydEF0LXQpLzEwMDA6KHMuZW5kQXQtdCkvMTAwMDtjb25zdCBkaXNwbGF5PXMucGhhc2U9PT0nY291bnRkb3duJz9NYXRoLm1heCgxLE1hdGguY2VpbChyZW1haW5pbmcpKTpNYXRoLm1heCgwLE1hdGguY2VpbChyZW1haW5pbmcpKTsKIGZvcihjb25zdCBpZCBvZiBbJ2hvc3RUaW1lcicsJ3BsYXllclRpbWVyJ10pe2NvbnN0IGVsPSQoaWQpO2lmKGVsKXtlbC50ZXh0Q29udGVudD1gJHtkaXNwbGF5fWA7ZWwuY2xhc3NMaXN0LnRvZ2dsZSgnd2FybmluZycscy5waGFzZT09PSdydW5uaW5nJyYmcmVtYWluaW5nPD0xMCk7fX0KIGNvbnN0IHBoYXNlPSQoJ3BoYXNlTGFiZWwnKTtpZihwaGFzZSlwaGFzZS50ZXh0Q29udGVudD1zLnBoYXNlPT09J2NvdW50ZG93bic/J/CfmqYg6rOnIOy2nOuwnO2VqeuLiOuLpCEnOnMucGhhc2U9PT0ncnVubmluZyc/cmVtYWluaW5nPD0xMD8n8J+UpSDrp4jsp4Drp4kgMTDstIghJzon7KCE7IaN66Cl7Jy866GcIOuLrOumrOuKlCDspJEhJzon7JmE7KO8ISc7CiBjb25zdCBwcm9ncmVzcz0kKCd0aW1lUHJvZ3Jlc3MnKTtpZihwcm9ncmVzcylwcm9ncmVzcy5zdHlsZS53aWR0aD1zLnBoYXNlPT09J2NvdW50ZG93bic/JzAlJzpgJHtNYXRoLm1heCgwLE1hdGgubWluKDEwMCwoMS1NYXRoLm1heCgwLHJlbWFpbmluZykvcy5kdXJhdGlvbikqMTAwKSl9JWA7CiBjb25zdCB0YXA9JCgndGFwWm9uZScpO2lmKHRhcCl0YXAuZGlzYWJsZWQ9cy5waGFzZSE9PSdydW5uaW5nJ3x8dDxzLnN0YXJ0QXR8fHQ+PXMuZW5kQXQ7CiBjb25zdCBtaW5lPXMucGxheWVycy5maW5kKHA9PnAuaWQ9PT1zZWxmSWQpO2lmKG1pbmUpe2NvbnN0IG51bT0kKCdteUNvdW50Jyk7aWYobnVtKW51bS50ZXh0Q29udGVudD1sb2NhbFRhcHN8fG1pbmUuc2NvcmU7Y29uc3QgcGw9JCgnbXlQbGFjZScpO2lmKHBsKXBsLnRleHRDb250ZW50PWAke3MucmFua2luZy5maW5kKHA9PnAuaWQ9PT1zZWxmSWQpPy5wbGFjZXx8Jy0nfeychGA7fQogY29uc3QgdHJhY2tzPSQoJ3RyYWNrcycpO2lmKHRyYWNrcyl7Y29uc3QgcmFuaz1zLnJhbmtpbmc7Y29uc3QgbWF4PU1hdGgubWF4KDEsLi4ucmFuay5tYXAocD0+cC5zY29yZSkpO3RyYWNrcy5pbm5lckhUTUw9cmFuay5tYXAocD0+YDxkaXYgY2xhc3M9InRyYWNrIj48ZGl2IGNsYXNzPSJ0cmFja3RvcCI+PHNwYW4+JHtwLnBsYWNlfeychCAke2VzY2FwZUhUTUwocC5uYW1lKX08L3NwYW4+PHNwYW4gY2xhc3M9InNjb3JlIj4ke3Auc2NvcmV9IFRBUDwvc3Bhbj48L2Rpdj48ZGl2IGNsYXNzPSJsYW5lIj48c3BhbiBjbGFzcz0icnVubmVyIiBzdHlsZT0ibGVmdDoke01hdGgubWF4KDAsTWF0aC5taW4oMTAwLChwLnNjb3JlL21heCkqOTgpKX0lIj7wn4+DPC9zcGFuPjwvZGl2PjwvZGl2PmApLmpvaW4oJycpO30KfQpmdW5jdGlvbiB0aWNrKCl7aWYoc3RhdGUmJihzdGF0ZS5waGFzZT09PSdydW5uaW5nJ3x8c3RhdGUucGhhc2U9PT0nY291bnRkb3duJykpdXBkYXRlTGl2ZSgpO3JlcXVlc3RBbmltYXRpb25GcmFtZSgoKT0+c2V0VGltZW91dCh0aWNrLDEwMCkpO30KYXN5bmMgZnVuY3Rpb24gaG9zdENvbW1hbmQoYWN0aW9uLHZhbHVlKXt0cnl7Y29uc3QgYj17cm9vbSx0b2tlbixhY3Rpb259O2lmKHZhbHVlIT09dW5kZWZpbmVkKWIudmFsdWU9dmFsdWU7YXdhaXQgcmVxdWVzdCgnL2FwaS9ob3N0JyxiKTt9Y2F0Y2goZSl7dG9hc3QoZS5tZXNzYWdlKTt9fQpmdW5jdGlvbiB0YXBOb3coZSl7aWYobW9kZSE9PSdwbGF5ZXInfHwhc3RhdGV8fHN0YXRlLnBoYXNlIT09J3J1bm5pbmcnKXJldHVybjtjb25zdCB0PURhdGUubm93KCkrY2xvY2tPZmZzZXQ7aWYodDxzdGF0ZS5zdGFydEF0fHx0Pj1zdGF0ZS5lbmRBdClyZXR1cm47Y29uc3QgZWxpZ2libGU9c3RhdGUucGxheWVycy5maW5kKHA9PnAuaWQ9PT1zZWxmSWQpPy5hY3RpdmU7aWYoIWVsaWdpYmxlKXJldHVybjtlLnByZXZlbnREZWZhdWx0KCk7bG9jYWxUYXBzKys7Y29uc3Qgbj0kKCdteUNvdW50Jyk7aWYobiluLnRleHRDb250ZW50PWxvY2FsVGFwcztpZihsb2NhbFRhcHMlMTc9PT0wJiZuYXZpZ2F0b3IudmlicmF0ZSluYXZpZ2F0b3IudmlicmF0ZSgxMik7fQphc3luYyBmdW5jdGlvbiBmbHVzaFRhcHMoKXtpZihtb2RlIT09J3BsYXllcid8fCFzdGF0ZXx8c3RhdGUucGhhc2UhPT0ncnVubmluZyd8fHNlbmRpbmd8fGxvY2FsVGFwczw9bGFzdFNlbnQpcmV0dXJuO3NlbmRpbmc9dHJ1ZTtjb25zdCB0b3RhbD1sb2NhbFRhcHM7dHJ5e2F3YWl0IHJlcXVlc3QoJy9hcGkvdGFwJyx7cm9vbSx0b2tlbix0b3RhbH0pO2xhc3RTZW50PXRvdGFsO31jYXRjaChlKXtpZighU3RyaW5nKGUubWVzc2FnZSkuaW5jbHVkZXMoJ+qyveq4sOuwqeydtCDsl4bsirXri4jri6QnKSljb25zb2xlLndhcm4oJ1RhcCByZXRyeScsZS5tZXNzYWdlKTt9ZmluYWxseXtzZW5kaW5nPWZhbHNlO319CmZ1bmN0aW9uIHRvbmUoZixkLGdhaW49LjEsdHlwZT0nc3F1YXJlJyl7aWYoIWF1ZGlvQ3R4KXJldHVybjtjb25zdCBvc2M9YXVkaW9DdHguY3JlYXRlT3NjaWxsYXRvcigpLGc9YXVkaW9DdHguY3JlYXRlR2FpbigpLHN0YXJ0PWF1ZGlvQ3R4LmN1cnJlbnRUaW1lO29zYy50eXBlPXR5cGU7b3NjLmZyZXF1ZW5jeS5zZXRWYWx1ZUF0VGltZShmLHN0YXJ0KTtnLmdhaW4uc2V0VmFsdWVBdFRpbWUoLjAwMDEsc3RhcnQpO2cuZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKE1hdGgubWF4KC4wMDEsZ2Fpbip2b2x1bWUpLHN0YXJ0Ky4wMTIpO2cuZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKC4wMDAxLHN0YXJ0K2QpO29zYy5jb25uZWN0KGcpO2cuY29ubmVjdChhdWRpb0N0eC5kZXN0aW5hdGlvbik7b3NjLnN0YXJ0KHN0YXJ0KTtvc2Muc3RvcChzdGFydCtkKy4wMik7fQpmdW5jdGlvbiBhcm1BdWRpbygpe2lmKCFzb3VuZEVuYWJsZWQpcmV0dXJuO3RyeXtjb25zdCBBPXdpbmRvdy5BdWRpb0NvbnRleHR8fHdpbmRvdy53ZWJraXRBdWRpb0NvbnRleHQ7aWYoIUEpcmV0dXJuO2lmKCFhdWRpb0N0eClhdWRpb0N0eD1uZXcgQSgpO2F1ZGlvQ3R4LnJlc3VtZSgpO31jYXRjaChlKXtjb25zb2xlLndhcm4oJ0F1ZGlvIGJsb2NrZWQnLGUpO319CmZ1bmN0aW9uIHBsYXlCZWF0KCl7aWYoIXNvdW5kRW5hYmxlZHx8IWF1ZGlvQ3R4fHwhc3RhdGV8fHN0YXRlLnBoYXNlIT09J3J1bm5pbmcnKXtyZXR1cm47fWNvbnN0IGxlZnQ9TWF0aC5tYXgoMCwoc3RhdGUuZW5kQXQtRGF0ZS5ub3coKS1jbG9ja09mZnNldCkvMTAwMCksdXJnZW50PWxlZnQ8PTEwLHBhdHRlcm49WzE5NiwyNDYuOTQsMjkzLjY2LDM5MiwzMjkuNjMsMjkzLjY2LDI0Ni45NCwzMjkuNjNdLG5vdGVzPXVyZ2VudD9bMzkyLDUyMy4yNSw0OTMuODgsNjU5LjI1XTpwYXR0ZXJuO2NvbnN0IGY9bm90ZXNbYmVhdEluZGV4JW5vdGVzLmxlbmd0aF07dG9uZShmLHVyZ2VudD8uMTI6LjE1LHVyZ2VudD8uMTM6LjA5NSwndHJpYW5nbGUnKTtpZihiZWF0SW5kZXglND09PTApdG9uZSg5OCwuMDgsLjA3NSwnc2luZScpO2lmKHVyZ2VudCl0b25lKDgwMCwuMDUsLjA1LCdzcXVhcmUnKTtiZWF0SW5kZXgrKzt9CmZ1bmN0aW9uIHN0YXJ0TXVzaWMoKXtzdG9wTXVzaWMoKTtpZighc291bmRFbmFibGVkKXJldHVybjthcm1BdWRpbygpO211c2ljVGltZXI9c2V0SW50ZXJ2YWwoKCk9PntwbGF5QmVhdCgpO30sMTg1KTt9CmZ1bmN0aW9uIHN0b3BNdXNpYygpe2lmKG11c2ljVGltZXIpe2NsZWFySW50ZXJ2YWwobXVzaWNUaW1lcik7bXVzaWNUaW1lcj1udWxsO319CmZ1bmN0aW9uIHByZXZpZXdNdXNpYygpe2lmKCFzb3VuZEVuYWJsZWQpe3RvYXN0KCfrqLzsoIAg7J2M7JWF7J2EIOy8nCDso7zshLjsmpQuJyk7cmV0dXJuO31hcm1BdWRpbygpO2xldCBpPTA7Y29uc3QgaWQ9c2V0SW50ZXJ2YWwoKCk9PntpZihpPj0xNCl7Y2xlYXJJbnRlcnZhbChpZCk7cmV0dXJuO31jb25zdCBmPVsyNjEuNjMsMzI5LjYzLDM5Miw1MjMuMjVdW2klNF07dG9uZShmLC4xOCwuMTIsJ3RyaWFuZ2xlJyk7aSsrO30sMTk1KTt0b2FzdCgn7J2M7JWF7J2EIDPstIjqsIQg66+466asIOuTo+yKteuLiOuLpC4nKTt9CmFzeW5jIGZ1bmN0aW9uIGNvcHlJbnZpdGUoKXt0cnl7YXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoc2hhcmVVcmwoKSk7dG9hc3QoJ+y0iOuMgCDrp4Htgazrpbwg67O17IKs7ZaI7Ja07JqUIScpO31jYXRjaHtjb25zdCBpbnB1dD1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZXh0YXJlYScpO2lucHV0LnZhbHVlPXNoYXJlVXJsKCk7aW5wdXQuc3R5bGUucG9zaXRpb249J2ZpeGVkJztpbnB1dC5zdHlsZS5vcGFjaXR5PScwJztkb2N1bWVudC5ib2R5LmFwcGVuZChpbnB1dCk7aW5wdXQuc2VsZWN0KCk7dHJ5e2lmKCFkb2N1bWVudC5leGVjQ29tbWFuZCgnY29weScpKXRocm93IEVycm9yKCk7dG9hc3QoJ+y0iOuMgCDrp4Htgazrpbwg67O17IKs7ZaI7Ja07JqUIScpO31jYXRjaHt0b2FzdCgn7JyE7JeQIOuztOydtOuKlCDrp4Htgazrpbwg6ri46rKMIOuIjOufrCDrs7XsgqztlbQg7KO87IS47JqULicpO31pbnB1dC5yZW1vdmUoKTt9fQphc3luYyBmdW5jdGlvbiBzaGFyZUludml0ZSgpe2lmKG5hdmlnYXRvci5zaGFyZSl7dHJ5e2F3YWl0IG5hdmlnYXRvci5zaGFyZSh7dGl0bGU6JzIwMjcg7ZaJ7Jq07J2YIOyniOyjvCcsdGV4dDpg6rK96riw67CpICR7cm9vbX3sl5Ag7J6F7J6l7ZW07IScIO2DrSDri6zrpqzquLAg6rKM7J6E7JeQIOywuOyXrO2VtOyalCFgLHVybDpzaGFyZVVybCgpfSk7cmV0dXJuO31jYXRjaChlKXtpZihlLm5hbWU9PT0nQWJvcnRFcnJvcicpcmV0dXJuO319YXdhaXQgY29weUludml0ZSgpO30KZnVuY3Rpb24gcmVzdG9yZSgpe2NvbnN0IHU9bmV3IFVSTChsb2NhdGlvbi5ocmVmKSxxPSh1LnNlYXJjaFBhcmFtcy5nZXQoJ3Jvb20nKXx8JycpLnRvVXBwZXJDYXNlKCksaD0odS5zZWFyY2hQYXJhbXMuZ2V0KCdob3N0Jyl8fCcnKS50b1VwcGVyQ2FzZSgpO2NvbnN0IGNvZGU9cXx8aDsKIGlmKGNvZGUgJiYgL15bQS1aMi05XXs2fSQvLnRlc3QoY29kZSkpe2NvbnN0IGhvc3RUb2tlbj1sb2NhbFN0b3JhZ2UuZ2V0SXRlbShgdGFwcnVuOmhvc3Q6JHtjb2RlfWApO2lmKGhvc3RUb2tlbil7cm9vbT1jb2RlO3Rva2VuPWhvc3RUb2tlbjttb2RlPSdob3N0Jztjb25uZWN0KCk7cmV0dXJuO31jb25zdCBwbGF5ZXJUb2tlbj1sb2NhbFN0b3JhZ2UuZ2V0SXRlbShgdGFwcnVuOnBsYXllcjoke2NvZGV9YCk7aWYocGxheWVyVG9rZW4pe3Jvb209Y29kZTt0b2tlbj1wbGF5ZXJUb2tlbjttb2RlPSdwbGF5ZXInO2Nvbm5lY3QoKTtyZXR1cm47fWpvaW5TY3JlZW4oY29kZSk7cmV0dXJuO31ob21lKCk7fQogZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLGFzeW5jIGU9Pntjb25zdCBidG49ZS50YXJnZXQuY2xvc2VzdCgnW2RhdGEtYWN0aW9uXScpO2lmKCFidG4pcmV0dXJuO2NvbnN0IGFjdGlvbj1idG4uZGF0YXNldC5hY3Rpb247c3dpdGNoKGFjdGlvbil7Y2FzZSAnY3JlYXRlJzphd2FpdCBjcmVhdGVSb29tKCk7YnJlYWs7Y2FzZSAnZW50ZXInOntjb25zdCBjb2RlPSgkKCdtYW51YWxSb29tJyk/LnZhbHVlfHwnJykudG9VcHBlckNhc2UoKS50cmltKCk7aWYoIS9eW0EtWjItOV17Nn0kLy50ZXN0KGNvZGUpKXt0b2FzdCgnNuyekOumrCDqsr3quLDrsKkg7L2U65Oc66W8IOyeheugpe2VmOyEuOyalC4nKTtyZXR1cm47fWpvaW5TY3JlZW4oY29kZSk7YnJlYWs7fWNhc2UgJ2pvaW4nOmF3YWl0IGpvaW5Sb29tKCk7YnJlYWs7Y2FzZSAnZHVyYXRpb24nOmF3YWl0IGhvc3RDb21tYW5kKCdkdXJhdGlvbicsTnVtYmVyKGJ0bi5kYXRhc2V0LnZhbHVlKSk7YnJlYWs7Y2FzZSAnc3RhcnQnOmFybUF1ZGlvKCk7YXdhaXQgaG9zdENvbW1hbmQoJ3N0YXJ0Jyk7YnJlYWs7Y2FzZSAncmVzZXQnOnN0b3BNdXNpYygpO2F3YWl0IGhvc3RDb21tYW5kKCdyZXNldCcpO2JyZWFrO2Nhc2UgJ2ZpbmFsJzpzdG9wTXVzaWMoKTthd2FpdCBob3N0Q29tbWFuZCgnZmluYWwnKTticmVhaztjYXNlICdjb3B5Jzphd2FpdCBjb3B5SW52aXRlKCk7YnJlYWs7Y2FzZSAnc2hhcmUnOmF3YWl0IHNoYXJlSW52aXRlKCk7YnJlYWs7Y2FzZSAnaG9tZSc6c3RvcE11c2ljKCk7aG9tZSgpO2JyZWFrO2Nhc2UgJ3NvdW5kJzpzb3VuZEVuYWJsZWQ9IXNvdW5kRW5hYmxlZDtidG4uY2xhc3NMaXN0LnRvZ2dsZSgnb24nLHNvdW5kRW5hYmxlZCk7YnRuLnNldEF0dHJpYnV0ZSgnYXJpYS1jaGVja2VkJyxTdHJpbmcoc291bmRFbmFibGVkKSk7aWYoIXNvdW5kRW5hYmxlZClzdG9wTXVzaWMoKTtlbHNlIGlmKHN0YXRlPy5waGFzZT09PSdydW5uaW5nJyl7YXJtQXVkaW8oKTtzdGFydE11c2ljKCk7fWJyZWFrO2Nhc2UgJ3ByZXZpZXcnOnByZXZpZXdNdXNpYygpO2JyZWFrO319KTsKIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJkb3duJyxlPT57aWYoZS50YXJnZXQuY2xvc2VzdCgnI3RhcFpvbmUnKSl0YXBOb3coZSk7fSx7cGFzc2l2ZTpmYWxzZX0pOwogZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsZT0+e2lmKGUua2V5PT09J0VudGVyJyYmZS50YXJnZXQuaWQ9PT0nbmlja25hbWUnKWpvaW5Sb29tKCk7aWYoZS5rZXk9PT0nRW50ZXInJiZlLnRhcmdldC5pZD09PSdtYW51YWxSb29tJyl7JCgnW2RhdGEtYWN0aW9uPSJlbnRlciJdJyk/LmNsaWNrKCk7fX0pOwogZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLGU9PntpZihlLnRhcmdldC5pZD09PSd2b2x1bWUnKXZvbHVtZT1OdW1iZXIoZS50YXJnZXQudmFsdWUpLzEwMDt9KTsKIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdiZWZvcmV1bmxvYWQnLCgpPT57aWYobW9kZT09PSdwbGF5ZXInJiZsb2NhbFRhcHM+bGFzdFNlbnQmJnN0YXRlPy5waGFzZT09PSdydW5uaW5nJyluYXZpZ2F0b3Iuc2VuZEJlYWNvbj8uKCcvYXBpL3RhcCcsbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KHtyb29tLHRva2VuLHRvdGFsOmxvY2FsVGFwc30pXSx7dHlwZTonYXBwbGljYXRpb24vanNvbid9KSk7fSk7CiBzZXRJbnRlcnZhbChmbHVzaFRhcHMsMzAwKTt0aWNrKCk7cmVzdG9yZSgpOwo=","base64"),
"style.css":Buffer.from("QGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9TnVuaXRvOndnaHRANjAwOzcwMDs4MDA7OTAwJmZhbWlseT1Ob3RvK1NhbnMrS1I6d2dodEA0MDA7NTAwOzYwMDs3MDA7ODAwOzkwMCZkaXNwbGF5PXN3YXAnKTsKOnJvb3R7Y29sb3Itc2NoZW1lOmRhcms7LS1iZzojMGMxMDIzOy0tc3VyZmFjZTojMTgxZjM5Oy0tc3VyZmFjZTI6IzIwMmI0YTstLXB1cnBsZTojYTc4YmZhOy0tY3lhbjojNmJlNmYwOy0tbGltZTojYjRmMzVjOy0tdGV4dDojZjZmN2ZmOy0tbXV0ZWQ6I2FjYjZkMTstLWJvcmRlcjojMzAzYzVjOy0tcGluazojZmY3Y2E3fSp7Ym94LXNpemluZzpib3JkZXItYm94fWh0bWwsYm9keXttYXJnaW46MDttaW4taGVpZ2h0OjEwMCU7b3ZlcnNjcm9sbC1iZWhhdmlvci15OmNvbnRhaW59Ym9keXtmb250LWZhbWlseTonTnVuaXRvJywnTm90byBTYW5zIEtSJyxzeXN0ZW0tdWksc2Fucy1zZXJpZjtiYWNrZ3JvdW5kOnJhZGlhbC1ncmFkaWVudChlbGxpcHNlIGF0IDUwJSAtMjAlLCMzNDM2NmYgMCx0cmFuc3BhcmVudCA1NSUpLHJhZGlhbC1ncmFkaWVudChlbGxpcHNlIGF0IDExMCUgNjAlLCMxODMxNGIgMCx0cmFuc3BhcmVudCA0MCUpLHZhcigtLWJnKTtjb2xvcjp2YXIoLS10ZXh0KTstd2Via2l0LXRhcC1oaWdobGlnaHQtY29sb3I6dHJhbnNwYXJlbnR9LmFwcHttYXgtd2lkdGg6NjUwcHg7bWFyZ2luOmF1dG87cGFkZGluZzoyMXB4IDE2cHggMzRweH0uYnJhbmR7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6MTBweDttYXJnaW4tYm90dG9tOjIycHh9LmJyYW5kLWJvbHR7d2lkdGg6NDNweDtoZWlnaHQ6NDNweDtib3JkZXItcmFkaXVzOjEzcHg7ZGlzcGxheTpncmlkO3BsYWNlLWl0ZW1zOmNlbnRlcjtiYWNrZ3JvdW5kOiMyZTM2Njc7Zm9udC1zaXplOjIycHg7Ym94LXNoYWRvdzowIDAgMzBweCAjYjA5MGZlM2R9LmJyYW5kIHN0cm9uZ3tmb250LXNpemU6MjNweDtmb250LXdlaWdodDo5MDA7bGV0dGVyLXNwYWNpbmc6LTFweH0uYnJhbmQgc3Ryb25nIHNwYW57Y29sb3I6dmFyKC0tbGltZSl9LmV5ZWJyb3d7Zm9udC1zaXplOjEwcHg7bGV0dGVyLXNwYWNpbmc6MnB4O2ZvbnQtd2VpZ2h0OjkwMDtjb2xvcjp2YXIoLS1jeWFuKX0uYnJhbmQtdGFne21hcmdpbi1sZWZ0OmF1dG87Y29sb3I6dmFyKC0tbGltZSk7Ym9yZGVyOjFweCBzb2xpZCAjYjRmMzVjNjY7Ym9yZGVyLXJhZGl1czoxMDBweDtwYWRkaW5nOjVweCA4cHg7Zm9udC1zaXplOjlweDtmb250LXdlaWdodDo5MDB9LmNhcmR7YmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQoMTY1ZGVnLCMxYzI0NDEsIzE1MWMzNCk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpO2JvcmRlci1yYWRpdXM6MjZweDtwYWRkaW5nOjIycHg7Ym94LXNoYWRvdzowIDEycHggNTBweCAjMDUwOTFlNTV9LndlbGNvbWV7dGV4dC1hbGlnbjpjZW50ZXI7cGFkZGluZzozM3B4IDI0cHh9LmJpZy1lbW9qaXtmb250LXNpemU6NjdweDtsaW5lLWhlaWdodDoxLjI7bWFyZ2luLWJvdHRvbToxNHB4fWgxe2ZvbnQtc2l6ZTozNHB4O2xpbmUtaGVpZ2h0OjEuMzttYXJnaW46MTBweCAwIDExcHg7bGV0dGVyLXNwYWNpbmc6LTEuNnB4fWgxIGVte2NvbG9yOnZhcigtLWxpbWUpO2ZvbnQtc3R5bGU6bm9ybWFsfXB7Y29sb3I6dmFyKC0tbXV0ZWQpO2xpbmUtaGVpZ2h0OjEuNztmb250LXNpemU6MTNweDttYXJnaW46MTBweCAwIDIycHh9YnV0dG9uLGlucHV0e2ZvbnQtZmFtaWx5OmluaGVyaXR9LmJ0bnttaW4taGVpZ2h0OjQ4cHg7Ym9yZGVyOjA7Ym9yZGVyLXJhZGl1czoxNXB4O3BhZGRpbmc6MTFweCAxN3B4O2ZvbnQtc2l6ZToxNHB4O2ZvbnQtd2VpZ2h0OjkwMDtjdXJzb3I6cG9pbnRlcjt3aGl0ZS1zcGFjZTpub3dyYXA7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjFzLG9wYWNpdHkgLjFzfS5idG46YWN0aXZle3RyYW5zZm9ybTpzY2FsZSguOTcpfS5idG46ZGlzYWJsZWR7b3BhY2l0eTouMzg7Y3Vyc29yOm5vdC1hbGxvd2VkfS5wcmltYXJ5e2JhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KDExMGRlZywjYzdmZTY0LCNhYWYxNTcpO2NvbG9yOiMxNDIwMTI7Ym94LXNoYWRvdzowIDhweCAyNHB4ICNjN2ZlNjQxZn0ubGlnaHR7YmFja2dyb3VuZDojMzQzZjY3O2NvbG9yOndoaXRlfS5zZWNvbmRhcnl7YmFja2dyb3VuZDojMmQzOTYxO2NvbG9yOndoaXRlfS5vdXRsaW5lZHtiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2JvcmRlcjoxcHggc29saWQgIzU2NjA4MDtjb2xvcjojZTdlZmZmfS5mdWxse3dpZHRoOjEwMCV9LnNlcGFyYXRvcntmb250LXNpemU6MTFweDtjb2xvcjojOGY5ZGJkO21hcmdpbjoyMHB4IDAgMTVweH0uZmllbGQtbGFiZWx7Zm9udC1zaXplOjEycHg7Y29sb3I6I2QzZGNmMjtmb250LXdlaWdodDo5MDA7ZGlzcGxheTpibG9jazt0ZXh0LWFsaWduOmxlZnQ7bWFyZ2luOjExcHggMCA4cHh9LmlubGluZXtkaXNwbGF5OmZsZXg7Z2FwOjlweH0uaW5wdXR7bWluLXdpZHRoOjA7d2lkdGg6MTAwJTtiYWNrZ3JvdW5kOiMwZTE0Mjk7Ym9yZGVyOjFweCBzb2xpZCAjMzU0NTY1O2JvcmRlci1yYWRpdXM6MTRweDtjb2xvcjp3aGl0ZTtwYWRkaW5nOjEzcHggMTRweDtvdXRsaW5lOm5vbmU7Zm9udC1zaXplOjE1cHh9LmlucHV0OmZvY3Vze2JvcmRlci1jb2xvcjp2YXIoLS1jeWFuKTtib3gtc2hhZG93OjAgMCAwIDJweCAjNmJlNmYwMWV9LmZvb3R7dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6IzcxODJhYTtmb250LXNpemU6MTBweDttYXJnaW46MjRweCAwfS5jYXJkKy5jYXJke21hcmdpbi10b3A6MTVweH0ucm93e2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjthbGlnbi1pdGVtczpjZW50ZXI7Z2FwOjEwcHh9LnNtYWxse2ZvbnQtc2l6ZToxMXB4O2NvbG9yOnZhcigtLW11dGVkKX0uaDJ7Zm9udC1zaXplOjIycHg7Zm9udC13ZWlnaHQ6OTAwO2xldHRlci1zcGFjaW5nOi0uN3B4O21hcmdpbjowfS50YWd7YmFja2dyb3VuZDojMzM0MjYwO2JvcmRlci1yYWRpdXM6OHB4O3BhZGRpbmc6NnB4IDEwcHg7Zm9udC13ZWlnaHQ6OTAwO2ZvbnQtc2l6ZToxMnB4O2NvbG9yOnZhcigtLWxpbWUpfS5waWxse2Rpc3BsYXk6aW5saW5lLWZsZXg7Ym9yZGVyLXJhZGl1czo5OXB4O2JhY2tncm91bmQ6IzI3MzE0ZDtjb2xvcjp2YXIoLS1tdXRlZCk7cGFkZGluZzo2cHggMTBweDtmb250LXNpemU6MTFweDtmb250LXdlaWdodDo4MDB9LmxhYmVse2NvbG9yOiNkNWRjZjM7Zm9udC1zaXplOjEzcHg7Zm9udC13ZWlnaHQ6OTAwfS5oaW50e2ZvbnQtc2l6ZToxMXB4O2NvbG9yOnZhcigtLW11dGVkKTtsaW5lLWhlaWdodDoxLjZ9LmRpdmlkZXJ7aGVpZ2h0OjFweDtiYWNrZ3JvdW5kOiMzNDQxNWQ7bWFyZ2luOjE5cHggMH0ucXItd3JhcHtiYWNrZ3JvdW5kOndoaXRlO2JvcmRlci1yYWRpdXM6MjBweDtwYWRkaW5nOjExcHg7bWFyZ2luOjE0cHggYXV0byAxMHB4O3dpZHRoOm1pbig3NCUsMjQwcHgpfS5xci13cmFwIGltZ3tkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCU7YXNwZWN0LXJhdGlvOjF9Lmludi11cmx7YmFja2dyb3VuZDojMTAxNzJjO2JvcmRlcjoxcHggZGFzaGVkICM0NDUxN2M7Ym9yZGVyLXJhZGl1czoxMnB4O3BhZGRpbmc6MTFweDtvdmVyZmxvdy13cmFwOmFueXdoZXJlO2ZvbnQtc2l6ZToxMXB4O2NvbG9yOiNjMWQ1ZmY7bGluZS1oZWlnaHQ6MS41NX0uYnV0dG9uc3tkaXNwbGF5OmZsZXg7Z2FwOjhweH0uYnV0dG9ucz4qe2ZsZXg6MX0uc2VnbWVudHtkaXNwbGF5OmZsZXg7YmFja2dyb3VuZDojMTAxNzJmO2JvcmRlcjoxcHggc29saWQgIzM0NDA1ZTtwYWRkaW5nOjVweDtnYXA6NXB4O2JvcmRlci1yYWRpdXM6MTVweH0uc2VnbWVudCBidXR0b257ZmxleDoxO2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6dmFyKC0tbXV0ZWQpO2JvcmRlcjpub25lO2JvcmRlci1yYWRpdXM6MTBweDtwYWRkaW5nOjExcHggNnB4O2ZvbnQtd2VpZ2h0OjkwMDtmb250LXNpemU6MTVweH0uc2VnbWVudCBidXR0b24uYWN0aXZle2JhY2tncm91bmQ6IzMzNDc3Mztjb2xvcjp3aGl0ZX0uY291bnR7Zm9udC1zaXplOjI0cHg7Zm9udC13ZWlnaHQ6OTAwO2NvbG9yOnZhcigtLWxpbWUpfS5jaGlwc3tkaXNwbGF5OmZsZXg7ZmxleC13cmFwOndyYXA7Z2FwOjZweDttYXJnaW4tdG9wOjExcHh9LmNoaXB7Zm9udC1zaXplOjEycHg7YmFja2dyb3VuZDojMjgzNDUyO2JvcmRlcjoxcHggc29saWQgIzNiNGE2YTtwYWRkaW5nOjdweCAxMHB4O2JvcmRlci1yYWRpdXM6OTlweH0ubXV0ZWR7Y29sb3I6dmFyKC0tbXV0ZWQpfS5zZWN0aW9ue21hcmdpbi10b3A6MjJweH0ucmFuZ2V7YWNjZW50LWNvbG9yOnZhcigtLWxpbWUpO3dpZHRoOjEwMCU7bWluLWhlaWdodDoyOXB4fS50b2dnbGV7d2lkdGg6NTBweDtoZWlnaHQ6MjlweDtib3JkZXItcmFkaXVzOjE1cHg7YmFja2dyb3VuZDojNGI1MzZiO2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7cGFkZGluZzozcHg7Y3Vyc29yOnBvaW50ZXJ9LnRvZ2dsZTpiZWZvcmV7Y29udGVudDonJztkaXNwbGF5OmJsb2NrO3dpZHRoOjIzcHg7aGVpZ2h0OjIzcHg7YmFja2dyb3VuZDp3aGl0ZTtib3JkZXItcmFkaXVzOjUwJTt0cmFuc2l0aW9uOnRyYW5zZm9ybSAuMTVzfS50b2dnbGUub257YmFja2dyb3VuZDojYjRmMzVjfS50b2dnbGUub246YmVmb3Jle3RyYW5zZm9ybTp0cmFuc2xhdGVYKDIxcHgpfS5yYWNlLXRvcHt0ZXh0LWFsaWduOmNlbnRlcn0udGltZXtmb250LXNpemU6NjRweDtsZXR0ZXItc3BhY2luZzotM3B4O2ZvbnQtd2VpZ2h0OjkwMDtmb250LXZhcmlhbnQtbnVtZXJpYzp0YWJ1bGFyLW51bXM7bWFyZ2luOjA7Y29sb3I6d2hpdGU7bGluZS1oZWlnaHQ6MS4zfS50aW1lLndhcm5pbmd7Y29sb3I6dmFyKC0tcGluayk7YW5pbWF0aW9uOmJlYXQgLjVzIGluZmluaXRlIGFsdGVybmF0ZX1Aa2V5ZnJhbWVzIGJlYXR7dG97dHJhbnNmb3JtOnNjYWxlKDEuMDQ1KX19LnByb2dyZXNze2hlaWdodDo4cHg7YmFja2dyb3VuZDojMTAxYjMxO2JvcmRlci1yYWRpdXM6OTlweDtvdmVyZmxvdzpoaWRkZW59LnByb2dyZXNzIGl7ZGlzcGxheTpibG9jaztoZWlnaHQ6MTAwJTtiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCg5MGRlZyx2YXIoLS1jeWFuKSx2YXIoLS1saW1lKSk7dHJhbnNpdGlvbjp3aWR0aCAuMnN9LnRyYWNre2JhY2tncm91bmQ6IzEwMTgyZjtib3JkZXI6MXB4IHNvbGlkICMzNTQzNjU7Ym9yZGVyLXJhZGl1czoxNnB4O3BhZGRpbmc6MTFweDttYXJnaW4tdG9wOjhweDtvdmVyZmxvdzpoaWRkZW59LnRyYWNrdG9we2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6c3BhY2UtYmV0d2VlbjtnYXA6MTBweDtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo5MDA7bWFyZ2luLWJvdHRvbTo4cHh9LmxhbmV7aGVpZ2h0OjE2cHg7YmFja2dyb3VuZDpyZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KDkwZGVnLCMyNjM2NTMsIzI2MzY1MyAyMHB4LCMxOTI3M2QgMjBweCwjMTkyNzNkIDQwcHgpO2JvcmRlci1yYWRpdXM6OHB4O3Bvc2l0aW9uOnJlbGF0aXZlO21hcmdpbi1yaWdodDoyMHB4fS5ydW5uZXJ7cG9zaXRpb246YWJzb2x1dGU7dG9wOi0xNXB4O3RyYW5zaXRpb246bGVmdCAuMzVzO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC04cHgpO2ZvbnQtc2l6ZToyOXB4O2ZpbHRlcjpkcm9wLXNoYWRvdygwIDVweCA1cHggIzAwMDcpfS5zY29yZXtmb250LXNpemU6MTJweDtjb2xvcjp2YXIoLS1saW1lKX0udGFwLXpvbmV7dG91Y2gtYWN0aW9uOm1hbmlwdWxhdGlvbjt1c2VyLXNlbGVjdDpub25lOy13ZWJraXQtdXNlci1zZWxlY3Q6bm9uZTtoZWlnaHQ6MjYwcHg7d2lkdGg6MTAwJTtib3JkZXItcmFkaXVzOjI1cHg7Ym9yZGVyOjNweCBzb2xpZCAjYzFmZDY5O2JhY2tncm91bmQ6cmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCAzOCUgMjUlLCNkOWZmOTIsI2IxZjA1YiA3MCUpO2NvbG9yOiMxNTIwMGI7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO2ZsZXgtZGlyZWN0aW9uOmNvbHVtbjtib3gtc2hhZG93OjAgOXB4IDAgIzUxNzcyZiwwIDE0cHggMzJweCAjYmRmNTZjM2Q7Y3Vyc29yOnBvaW50ZXI7bWFyZ2luOjI1cHggMCAxMHB4fS50YXAtem9uZTphY3RpdmV7dHJhbnNmb3JtOnRyYW5zbGF0ZVkoNHB4KTtib3gtc2hhZG93OjAgNHB4IDAgIzUxNzcyZiwwIDhweCAyMHB4ICNiZGY1NmMzZH0udGFwLXpvbmU6ZGlzYWJsZWR7b3BhY2l0eTouNDU7ZmlsdGVyOmdyYXlzY2FsZSguNyk7Y3Vyc29yOm5vdC1hbGxvd2VkfS50YXAtem9uZSAuaGFuZHtmb250LXNpemU6NjRweH0udGFwLXpvbmUgLnRhcC10aXRsZXtmb250LXdlaWdodDo5MDA7Zm9udC1zaXplOjMzcHg7bGV0dGVyLXNwYWNpbmc6LTFweH0udGFwLXpvbmUgLnRhcC1zdWJ7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6ODAwfS5tZS1jb3VudHtmb250LXNpemU6NTJweDtmb250LXdlaWdodDo5MDA7bGluZS1oZWlnaHQ6MS4xNTtjb2xvcjp2YXIoLS1saW1lKX0ucG9kaXVte2Rpc3BsYXk6Z3JpZDtncmlkLXRlbXBsYXRlLWNvbHVtbnM6MWZyIDEuMTVmciAxZnI7YWxpZ24taXRlbXM6ZW5kO2dhcDo3cHg7bWFyZ2luOjIzcHggMH0ucG9kaXVtIC5wZXJzb257cGFkZGluZzoxNnB4IDZweDtiYWNrZ3JvdW5kOiMyNjM0NTE7Ym9yZGVyLXJhZGl1czoxNnB4IDE2cHggOHB4IDhweDt0ZXh0LWFsaWduOmNlbnRlcjttaW4taGVpZ2h0OjEwN3B4fS5wb2RpdW0gLmZpcnN0e2JhY2tncm91bmQ6bGluZWFyLWdyYWRpZW50KCM1NTQ5MmMsI2E4OGE0Mik7bWluLWhlaWdodDoxNDJweH0ucG9kaXVtIC5tZWRhbHtmb250LXNpemU6MjdweH0ucG9kaXVtIC5uYW1le292ZXJmbG93LXdyYXA6YW55d2hlcmU7Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6OTAwO21hcmdpbjo2cHggMH0ucG9kaXVtIC5wb2ludHN7Zm9udC1zaXplOjEwcHh9LnJlc3VsdC1yb3d7ZGlzcGxheTpmbGV4O2p1c3RpZnktY29udGVudDpzcGFjZS1iZXR3ZWVuO2JvcmRlci1ib3R0b206MXB4IHNvbGlkICMzMzNlNWI7cGFkZGluZzoxMnB4IDRweDtmb250LXNpemU6MTJweH0uZW1wdHl7dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6IzhiOWNiOTtwYWRkaW5nOjE1cHggMDtmb250LXNpemU6MTJweH0ubm90aWNle2JhY2tncm91bmQ6IzI2MzU0YTtib3JkZXItbGVmdDozcHggc29saWQgdmFyKC0tY3lhbik7Ym9yZGVyLXJhZGl1czo1cHggMTFweCAxMXB4IDVweDtwYWRkaW5nOjExcHg7Zm9udC1zaXplOjEycHg7Y29sb3I6I2NkZGNmNTtsaW5lLWhlaWdodDoxLjZ9LnN1Y2Nlc3N7Y29sb3I6dmFyKC0tbGltZSl9I3RvYXN0e3Bvc2l0aW9uOmZpeGVkO3RvcDoxNHB4O2xlZnQ6NTAlO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpO21heC13aWR0aDo5MCU7YmFja2dyb3VuZDojZjhmYWZmO2NvbG9yOiMxMTFjMzM7cGFkZGluZzoxMnB4IDE4cHg7Ym9yZGVyLXJhZGl1czoxMnB4O2JveC1zaGFkb3c6MCAxMnB4IDQwcHggIzAwMDY7Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6OTAwO3otaW5kZXg6OTk7b3BhY2l0eTowO3BvaW50ZXItZXZlbnRzOm5vbmU7dHJhbnNpdGlvbjpvcGFjaXR5IC4yc30jdG9hc3Quc2hvd3tvcGFjaXR5OjF9Ym9keS5yYWNpbmcgLmFwcHtwYWRkaW5nLWJvdHRvbTo5cHh9QG1lZGlhKG1pbi13aWR0aDo1NTBweCl7LmFwcHtwYWRkaW5nLXRvcDozMHB4fS53ZWxjb21le3BhZGRpbmc6NDhweH0udGFwLXpvbmV7aGVpZ2h0OjMwMHB4fX1AbWVkaWEobWF4LXdpZHRoOjM1MHB4KXsuYnRue2ZvbnQtc2l6ZToxMnB4O3BhZGRpbmc6MTBweCAxMnB4fS5jYXJke3BhZGRpbmc6MTdweH0uaDJ7Zm9udC1zaXplOjIwcHh9LnRpbWV7Zm9udC1zaXplOjU2cHh9fQo=","base64")
};
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.svg':'image/svg+xml; charset=utf-8','.png':'image/png'};
const server=http.createServer(async (req,res)=>{
  const u=new URL(req.url,'http://localhost'); const route=u.pathname;
  try {
    if(req.method==='GET'&&route==='/health')return send(res,200,{ok:true,rooms:rooms.size});
    if(req.method==='POST'&&route==='/api/create') {
      const code=roomCode(), token=rand(24);
      const r={code,hostToken:token,players:[],clients:new Set(),phase:'waiting',round:1,configuredDuration:60,duration:60,eligible:null,startAt:0,endAt:0,lastSeen:now()};rooms.set(code,r);
      return send(res,201,{room:code,hostToken:token});
    }
    if(req.method==='POST'&&route==='/api/join') {
      const b=await parseBody(req);const r=roomFor(String(b.room||'').toUpperCase());if(!r)return error(res,404,'경기방이 없거나 종료되었습니다.');
      if(r.phase!=='waiting')return error(res,409,'경기가 시작되어 지금은 입장할 수 없습니다.');
      const name=String(b.name||'').trim().replace(/[<>]/g,'').slice(0,16);
      if(name.length<1)return error(res,400,'이름 또는 닉네임을 입력하세요.');
      if(r.players.length>=MAX_PLAYERS)return error(res,409,'참가 인원이 19명으로 가득 찼습니다.');
      if(r.players.some(p=>p.name.toLowerCase()===name.toLowerCase()))return error(res,409,'같은 이름이 있어요. 다른 이름을 입력해 주세요.');
      const p={id:rand(6),token:rand(24),name,score:0,joined:now(),lastReported:0,lastAccepted:now(),tapWindowStart:now(),tapWindowCount:0};r.players.push(p);r.lastSeen=now();publish(r);
      return send(res,201,{room:r.code,playerToken:p.token,playerId:p.id});
    }
    if(req.method==='POST'&&route==='/api/host') {
      const b=await parseBody(req);const r=roomFor(String(b.room||'').toUpperCase());if(!r)return error(res,404,'경기방이 없습니다.');
      if(b.token!==r.hostToken)return error(res,403,'진행자 권한이 없습니다.');
      r.lastSeen=now();advance(r);
      switch(b.action){
        case 'duration':if(r.phase!=='waiting'||r.round!==1)return error(res,409,'시작 전 일반 경기에서만 시간을 변경할 수 있습니다.');if(![60,120].includes(b.value))return error(res,400,'60초 또는 120초만 선택 가능합니다.');r.configuredDuration=b.value;r.duration=b.value;break;
        case 'start':if(r.phase!=='waiting')return error(res,409,'이미 경기가 시작되었습니다.');if(r.players.length<1)return error(res,409,'참가자가 입장한 뒤 시작하세요.');r.startAt=now()+4000;r.endAt=r.startAt+r.duration*1000;r.phase='countdown';break;
        case 'reset':r.round=1;r.eligible=null;r.phase='waiting';r.duration=r.configuredDuration;r.startAt=0;r.endAt=0;r.players.forEach(p=>{p.score=0;p.lastReported=0;p.tapWindowCount=0;p.tapWindowStart=now();});break;
        case 'final':{
          if(r.phase!=='finished')return error(res,409,'경기 종료 후에 결승전을 열 수 있습니다.');const best=rank(r);const top=best[0]?.score;
          const tied=best.filter(p=>p.score===top);if(tied.length<2)return error(res,409,'공동 1위가 없어서 결승전이 필요하지 않습니다.');
          r.eligible=tied.map(p=>p.id);r.round=2;r.duration=10;r.phase='waiting';r.startAt=0;r.endAt=0;r.players.forEach(p=>{p.score=0;p.lastReported=0;p.tapWindowCount=0;p.tapWindowStart=now();});break;}
        default:return error(res,400,'지원하지 않는 명령입니다.');
      }
      publish(r);return send(res,200,{ok:true});
    }
    if(req.method==='POST'&&route==='/api/tap') {
      const b=await parseBody(req);const r=roomFor(String(b.room||'').toUpperCase());if(!r)return error(res,404,'경기방이 없습니다.');
      const a=auth(r,b.token);if(!a||a.type!=='player')return error(res,403,'참가자 인증이 필요합니다.');
      advance(r);const p=a.player;const t=now();
      if(r.phase!=='running'||t>r.endAt||r.eligible&&!r.eligible.includes(p.id))return send(res,200,{ok:false,score:p.score});
      const total=Number(b.total);if(!Number.isSafeInteger(total)||total<0)return error(res,400,'점수 데이터가 올바르지 않습니다.');
      let delta=Math.max(0,total-p.lastReported); p.lastReported=Math.max(p.lastReported,total);
      if(t-p.tapWindowStart>=1000){p.tapWindowStart=t;p.tapWindowCount=0;}
      const allowed=Math.max(0,45-p.tapWindowCount);delta=Math.min(allowed,delta,60);
      p.score+=delta;p.tapWindowCount+=delta;p.lastAccepted=t;r.lastSeen=t;
      publish(r);return send(res,200,{ok:true,score:p.score});
    }
    if(req.method==='GET'&&route==='/api/stream') {
      const code=String(u.searchParams.get('room')||'').toUpperCase(), token=u.searchParams.get('token');const r=roomFor(code);if(!r)return error(res,404,'경기방이 없습니다.');const who=auth(r,token);if(!who)return error(res,403,'입장 정보가 유효하지 않습니다.');
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','Access-Control-Allow-Origin':'same-origin'});
      const client={res,who};r.clients.add(client);res.write('retry: 1500\n\n');res.write(`event: state\ndata: ${JSON.stringify(publicState(r,who))}\n\n`);req.on('close',()=>r.clients.delete(client));r.lastSeen=now();return;
    }
    if(req.method==='GET'&&route==='/api/qr.svg'){
      const code=String(u.searchParams.get('room')||'').toUpperCase();if(!validRoom(code)||!roomFor(code))return error(res,404,'경기방이 없습니다.');
      // Origin comes from the current browser location; restrict untrusted headers to valid host characters.
      const hostname=String(req.headers['x-forwarded-host']||req.headers.host||'').split(',')[0].trim();if(!/^[a-z0-9.:-]+$/i.test(hostname))return error(res,400,'주소 오류');
      const protocol=req.headers['x-forwarded-proto']==='https'?'https':req.socket.encrypted?'https':'http';const url=`${protocol}://${hostname}/?room=${code}`;
      const svg=svgQR(url);res.writeHead(200,{'Content-Type':'image/svg+xml; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'",'X-Content-Type-Options':'nosniff'});return res.end(svg);
    }
    if(req.method==='GET'&&(route==='/'||route==='/index.html'||route==='/app.js'||route==='/style.css')){
      const file=route==='/'?'index.html':route.replace(/^\//,'');const data=__ASSETS[file];const ext=file.slice(file.lastIndexOf('.'));
      res.writeHead(200,{'Content-Type':mime[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-store':'public, max-age=300','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});return res.end(data);
    }
    return error(res,404,'페이지를 찾을 수 없습니다.');
  } catch(e) {console.error(e);if(!res.headersSent)error(res,500,e?.message||'일시적인 오류가 발생했습니다.');}
});
setInterval(()=>{for(const [code,r] of rooms){advance(r);if(now()-r.lastSeen>ROOM_TTL){for(const c of r.clients)try{c.res.end();}catch{}rooms.delete(code);}}},250).unref();
setInterval(()=>{for(const r of rooms.values())for(const c of r.clients)try{c.res.write(': ping\n\n');}catch{r.clients.delete(c);}},20000).unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`TapRun listening on port ${PORT}`));
